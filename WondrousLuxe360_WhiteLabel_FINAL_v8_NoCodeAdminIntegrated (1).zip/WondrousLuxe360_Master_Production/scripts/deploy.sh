#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/infra/docker"
[ -f .env ] || { echo 'Create infra/docker/.env from .env.example and set real secrets.'; exit 1; }
docker compose up -d --build
docker compose ps
curl -fsS http://127.0.0.1:8080/health/ready
