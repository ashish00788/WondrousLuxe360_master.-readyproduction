#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/backend"
for f in $(find src tests -name '*.js' | sort); do node --check "$f"; done
cd "$ROOT"
node -e "JSON.parse(require('fs').readFileSync('config/white-label-default.json','utf8')); console.log('white-label config: OK')"
echo 'Static validation: PASS'
