import { z } from 'zod';

const schema = z.object({
  NODE_ENV: z.enum(['development','test','production']).default('production'),
  PORT: z.coerce.number().int().min(1).max(65535).default(8080),
  DATABASE_URL: z.string().min(20),
  DATABASE_SSL: z.enum(['true','false']).default('false'),
  RAZORPAY_KEY_ID: z.string().optional(),
  RAZORPAY_KEY_SECRET: z.string().optional(),
  RAZORPAY_WEBHOOK_SECRET: z.string().optional(),
  LOG_LEVEL: z.string().default('info'),
  APP_ORIGIN: z.string().optional(),
  ADMIN_API_KEY: z.string().min(24),
  INTEGRATION_ENCRYPTION_KEY: z.string().regex(/^[0-9a-fA-F]{64}$/).optional()
});
export const env = schema.parse(process.env);
