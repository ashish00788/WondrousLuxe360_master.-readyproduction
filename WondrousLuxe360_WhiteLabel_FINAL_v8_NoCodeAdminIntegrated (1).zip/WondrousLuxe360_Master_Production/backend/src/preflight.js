import { pool } from './db.js';
await pool.query('SELECT 1');
const r = await pool.query("SELECT version FROM schema_migrations ORDER BY applied_at DESC LIMIT 1");
console.log(JSON.stringify({ok:true,database:true,latestMigration:r.rows[0]?.version ?? null}));
await pool.end();
