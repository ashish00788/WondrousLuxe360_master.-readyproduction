import express from 'express';
import { simulateWhiteLabelModel, validateDynamicStructure, calculateCoupon } from '../services/worldModel.js';
const router=express.Router();
router.use(express.json({limit:'2mb'}));
router.post('/simulate',async(req,res,next)=>{try{res.json({ok:true,mode:'SIMULATION',simulation:simulateWhiteLabelModel(req.body)})}catch(e){next(e)}});
router.post('/coupon',async(req,res,next)=>{try{res.json({ok:true,...calculateCoupon(req.body)})}catch(e){next(e)}});
router.post('/structure/validate',async(req,res,next)=>{try{res.json({ok:true,structure:validateDynamicStructure(req.body)})}catch(e){next(e)}});
export default router;
