import express from 'express';
import { pool } from '../db.js';
const router=express.Router();
router.use(express.json({limit:'2mb'}));

router.get('/catalog', async (_req,res,next)=>{
  try{
    const q=await pool.query(`SELECT service_code,provider_name,active,commission_rules FROM service_providers WHERE business_id=(SELECT id FROM businesses WHERE slug='wondrousluxe360' LIMIT 1) ORDER BY service_code`);
    res.json({ok:true,services:q.rows});
  }catch(e){next(e)}
});

router.post('/quote', async (req,res,next)=>{
  try{
    const {serviceCode,providerCost,customerPrice,commissionPct=0,fixedFee=0,taxPct=0,currency='INR'}=req.body||{};
    const pc=Number(providerCost), cp=Number(customerPrice), c=Number(commissionPct), f=Number(fixedFee), t=Number(taxPct);
    if(!Number.isFinite(pc)||!Number.isFinite(cp)||pc<0||cp<0||!Number.isFinite(c)||!Number.isFinite(f)||!Number.isFinite(t)) return res.status(400).json({error:'INVALID_QUOTE'});
    const commission=(cp*c/100)+f;
    const tax=commission*t/100;
    res.json({ok:true,serviceCode,currency,providerCost:pc,customerPrice:cp,commission:commission.toFixed(2),commissionTax:tax.toFixed(2),grossMargin:(cp-pc).toFixed(2)});
  }catch(e){next(e)}
});
export default router;
