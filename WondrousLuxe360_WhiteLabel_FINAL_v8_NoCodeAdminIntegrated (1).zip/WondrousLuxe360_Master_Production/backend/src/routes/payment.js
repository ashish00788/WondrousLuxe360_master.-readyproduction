import express from 'express';
import crypto from 'node:crypto';
import { pool } from '../db.js';
import { requestHash, beginIdempotency } from '../services/idempotency.js';
import { makeGatewayOrderId, createRazorpayOrder } from '../services/razorpay.js';
const router=express.Router();
router.post('/orders',async(req,res,next)=>{
 const key=req.header('x-idempotency-key'); if(!key) return res.status(400).json({error:'MISSING_IDEMPOTENCY_KEY'});
 const amount=Number(req.body?.amountPaise), userId=req.body?.userId, packageId=req.body?.packageId ?? null;
 if(!Number.isSafeInteger(amount)||amount<=0||amount>9_000_000_000_000) return res.status(400).json({error:'INVALID_AMOUNT_PAISE'});
 if(typeof userId!=='string') return res.status(400).json({error:'INVALID_USER_ID'});
 const hash=requestHash(req), client=await pool.connect();
 try{await client.query('BEGIN'); const old=await beginIdempotency(client,key,hash); if(old){await client.query('COMMIT');return res.status(old.response_status).json(old.response_body);}
  const localId=makeGatewayOrderId(); const businessSlug=req.header('x-business-slug')||'wondrousluxe360';
  const gateway=await createRazorpayOrder({amountPaise:amount,receipt:localId,notes:{packageId:packageId??''},businessSlug});
  const p=await client.query(`INSERT INTO payment_transactions(user_id,gateway_order_id,amount,status) VALUES($1,$2,$3,'CREATED') RETURNING id`,[userId,gateway.id,String(amount)]);
  const body={success:true,paymentId:p.rows[0].id,gatewayOrderId:gateway.id,amountPaise:amount,currency:'INR',gatewayKeyId:gateway?.key_id||null};
  await client.query(`INSERT INTO idempotency_records(idempotency_key,request_hash,resource_id,response_status,response_body,expires_at) VALUES($1,$2,$3,201,$4,now()+interval '24 hours')`,[key,hash,p.rows[0].id,body]);
  await client.query('COMMIT'); res.status(201).json(body);
 }catch(e){await client.query('ROLLBACK').catch(()=>{});next(e)}finally{client.release()}
});
export default router;
