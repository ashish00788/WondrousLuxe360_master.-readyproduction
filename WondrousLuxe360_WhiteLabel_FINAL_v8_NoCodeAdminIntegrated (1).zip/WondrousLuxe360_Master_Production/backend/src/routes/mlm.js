import express from 'express';
import { buildDefaultMlmRules, validateMlmRules, simulateBinary, buildNonWorkingSchedule } from '../services/mlmEngine.js';
const router=express.Router(); router.use(express.json({limit:'1mb'}));
router.get('/rules',(_req,res)=>res.json({ok:true,rules:buildDefaultMlmRules()}));
router.post('/simulate',(_req,res,next)=>{try{const body=_req.body||{};res.json({ok:true,simulation:simulateBinary(body)});}catch(e){next(e)}});
router.post('/non-working-schedule',(_req,res,next)=>{try{res.json({ok:true,schedule:buildNonWorkingSchedule(_req.body?.activeBadges||[],_req.body?.rules||buildDefaultMlmRules())});}catch(e){next(e)}});
router.post('/validate-rules',(_req,res,next)=>{try{res.json({ok:true,rules:validateMlmRules(_req.body||{})});}catch(e){next(e)}});
export default router;
