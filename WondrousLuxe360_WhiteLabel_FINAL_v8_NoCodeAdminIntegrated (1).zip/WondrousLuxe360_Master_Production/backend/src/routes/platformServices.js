import express from 'express';
import { adapterFromEnv } from '../services/adapters/providerAdapter.js';
import { adapterFromIntegration, getBusiness } from '../services/integrationManager.js';
import { ALL_SERVICE_CODES, SERVICE_CATALOG, isServiceCode } from '../services/adapters/serviceCatalog.js';
const router=express.Router(); router.use(express.json({limit:'2mb'}));

router.get('/catalog',(_req,res)=>res.json({ok:true,categories:SERVICE_CATALOG,serviceCount:ALL_SERVICE_CODES.length,services:ALL_SERVICE_CODES}));
router.get('/status',async(req,res,next)=>{try{const b=await getBusiness(req.header('x-business-slug')||'wondrousluxe360');const services=[];for(const code of ALL_SERVICE_CODES){const stored=await adapterFromIntegration({businessId:b.id,serviceCode:code,environment:'live'});const a=stored?.adapter||adapterFromEnv(code);services.push({code,configured:a.configured(),provider:a.providerName||null,authType:a.authType,source:stored?'ADMIN_VAULT':'ENV_FALLBACK'});}res.json({ok:true,services})}catch(e){next(e)}});

async function dispatch(req,res,next,action){
  try{
    const code=req.params.serviceCode;
    if(!isServiceCode(code)) return res.status(404).json({error:'UNKNOWN_SERVICE'});
    const b=await getBusiness(req.header('x-business-slug')||'wondrousluxe360');
    const stored=await adapterFromIntegration({businessId:b.id,serviceCode:code,environment:req.body?.environment==='sandbox'?'sandbox':'live'});
    const a=stored?.adapter||adapterFromEnv(code);
    const envKey=code.toUpperCase().replace(/[^A-Z0-9]/g,'_');
    const path=stored?.stored?.config?.[`${action}Path`] || process.env[`${envKey}_${action.toUpperCase()}_PATH`] || `/${action}`;
    const data=await a.request(path,{method:'POST',body:req.body});
    res.json({ok:true,serviceCode:code,action,data});
  }catch(e){next(e)}
}
router.post('/:serviceCode/search',(req,res,next)=>dispatch(req,res,next,'search'));
router.post('/:serviceCode/quote',(req,res,next)=>dispatch(req,res,next,'quote'));
router.post('/:serviceCode/validate',(req,res,next)=>dispatch(req,res,next,'validate'));
router.post('/:serviceCode/book',(req,res,next)=>dispatch(req,res,next,'book'));
router.post('/:serviceCode/pay',(req,res,next)=>dispatch(req,res,next,'pay'));
router.post('/:serviceCode/cancel',(req,res,next)=>dispatch(req,res,next,'cancel'));
router.post('/:serviceCode/status',(req,res,next)=>dispatch(req,res,next,'status'));
router.post('/:serviceCode/refund',(req,res,next)=>dispatch(req,res,next,'refund'));
export default router;
