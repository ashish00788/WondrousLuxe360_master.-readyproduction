import express from 'express';
import { requireAdmin } from '../middleware/admin.js';
import {
  getBusiness,listIntegrations,providerCatalog,providerDefinition,saveIntegration,setActive,testIntegration,loadActiveCredentials,maskedCredentials,publicIntegration
} from '../services/integrationManager.js';

const router=express.Router();
router.use(express.json({limit:'256kb'}),requireAdmin);

router.get('/providers',(_req,res)=>res.json({ok:true,providers:providerCatalog()}));
router.get('/',async(req,res,next)=>{try{const b=await getBusiness(req.header('x-business-slug')||'wondrousluxe360');res.json({ok:true,integrations:(await listIntegrations(b.id)).map(publicIntegration)})}catch(e){next(e)}});

router.post('/',async(req,res,next)=>{try{
  const b=await getBusiness(req.header('x-business-slug')||'wondrousluxe360');
  const {serviceCode,providerName,environment='sandbox',credentials,config={},active=false}=req.body||{};
  if(!serviceCode||!providerName) return res.status(400).json({error:'SERVICE_AND_PROVIDER_REQUIRED'});
  const row=await saveIntegration({businessId:b.id,serviceCode,providerName,environment,credentials,config,active:false});
  const masked=maskedCredentials(credentials);
  await (await import('../db.js')).pool.query('INSERT INTO admin_audit_log(action,target_type,target_id,metadata) VALUES($1,$2,$3,$4)',['INTEGRATION_SAVED','INTEGRATION',row.id,{serviceCode,providerName,environment,credentialFields:Object.keys(masked)}]);
  res.status(201).json({ok:true,integration:publicIntegration(row),credentials:masked,notice:'Saved securely. Run Test Connection before activation.'});
}catch(e){next(e)}});

router.post('/:id/test',async(req,res,next)=>{try{const b=await getBusiness(req.header('x-business-slug')||'wondrousluxe360');const result=await testIntegration({businessId:b.id,id:req.params.id});res.json({ok:result.verification_status==='VERIFIED',integration:publicIntegration(result)})}catch(e){next(e)}});
router.post('/:id/activate',async(req,res,next)=>{try{const b=await getBusiness(req.header('x-business-slug')||'wondrousluxe360');const result=await setActive({businessId:b.id,id:req.params.id,active:true});res.json({ok:true,integration:result})}catch(e){next(e)}});
router.post('/:id/deactivate',async(req,res,next)=>{try{const b=await getBusiness(req.header('x-business-slug')||'wondrousluxe360');const result=await setActive({businessId:b.id,id:req.params.id,active:false});res.json({ok:true,integration:result})}catch(e){next(e)}});

router.get('/:id/credentials',async(req,res,next)=>{try{const b=await getBusiness(req.header('x-business-slug')||'wondrousluxe360');const {pool}=await import('../db.js');const q=await pool.query('SELECT encrypted_credentials FROM integration_credentials WHERE id=$1 AND business_id=$2',[req.params.id,b.id]);if(!q.rowCount)return res.status(404).json({error:'INTEGRATION_NOT_FOUND'});const {decryptCredentials}=await import('../services/integrationVault.js');res.json({ok:true,credentials:maskedCredentials(decryptCredentials(q.rows[0].encrypted_credentials))})}catch(e){next(e)}});

export default router;
