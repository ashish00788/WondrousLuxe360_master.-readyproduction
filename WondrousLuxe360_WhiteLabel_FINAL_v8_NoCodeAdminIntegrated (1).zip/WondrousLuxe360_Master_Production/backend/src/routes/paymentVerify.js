import express from 'express';
import crypto from 'node:crypto';
import { pool } from '../db.js';
import { getBusiness, loadActiveCredentials } from '../services/integrationManager.js';
const router=express.Router();
router.use(express.json({limit:'100kb'}));
router.post('/verify',async(req,res,next)=>{try{
 const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body||{};
 if(!razorpay_order_id||!razorpay_payment_id||!razorpay_signature) return res.status(400).json({error:'MISSING_PAYMENT_FIELDS'});
 const b=await getBusiness(req.header('x-business-slug')||'wondrousluxe360');
 const stored=await loadActiveCredentials({businessId:b.id,serviceCode:'payment',providerName:'razorpay',environment:'live'});
 const secret=stored?.credentials?.key_secret||process.env.RAZORPAY_KEY_SECRET; if(!secret) return res.status(503).json({error:'RAZORPAY_NOT_CONFIGURED'});
 const expected=crypto.createHmac('sha256',secret).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
 if(!/^[0-9a-fA-F]{64}$/.test(razorpay_signature) || !crypto.timingSafeEqual(Buffer.from(expected,'hex'),Buffer.from(razorpay_signature,'hex'))) return res.status(400).json({error:'INVALID_PAYMENT_SIGNATURE'});
 const q=await pool.query(`UPDATE payment_transactions SET gateway_payment_id=$1,status=CASE WHEN status='CREATED' THEN 'AUTHORIZED' ELSE status END,updated_at=now() WHERE gateway_order_id=$2 RETURNING id,status,amount,currency`,[razorpay_payment_id,razorpay_order_id]);
 if(!q.rowCount) return res.status(404).json({error:'PAYMENT_ORDER_NOT_FOUND'});
 res.json({verified:true,payment:q.rows[0]});
}catch(e){next(e)}});
export default router;
