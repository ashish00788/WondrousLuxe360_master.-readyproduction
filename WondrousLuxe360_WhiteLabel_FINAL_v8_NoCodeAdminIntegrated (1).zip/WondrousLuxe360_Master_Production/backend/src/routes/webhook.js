import express from 'express';
import { pool } from '../db.js';
import { env } from '../config.js';
import { verifyHmac } from '../services/hmac.js';
import { getBusiness, loadActiveCredentials } from '../services/integrationManager.js';
const router=express.Router();
router.post('/razorpay',express.raw({type:'application/json',limit:'2mb'}),async(req,res,next)=>{
 try{
  const signature=req.header('x-razorpay-signature'); const eventId=req.header('x-razorpay-event-id');
  const raw=Buffer.isBuffer(req.body)?req.body:Buffer.from(req.body??'');
  const b=await getBusiness(req.header('x-business-slug')||'wondrousluxe360');
  const stored=await loadActiveCredentials({businessId:b.id,serviceCode:'payment',providerName:'razorpay',environment:'live'});
  const webhookSecret=stored?.credentials?.webhook_secret||env.RAZORPAY_WEBHOOK_SECRET;
  if(!eventId||!signature||!verifyHmac(raw,signature,webhookSecret)) return res.status(400).json({error:'INVALID_WEBHOOK_SIGNATURE'});
  let p; try{p=JSON.parse(raw.toString('utf8'))}catch{return res.status(400).json({error:'INVALID_JSON'})}
  const payment=p?.payload?.payment?.entity; if(!p?.event||!payment) return res.status(400).json({error:'UNSUPPORTED_WEBHOOK_PAYLOAD'});
  const client=await pool.connect();
  try{await client.query('BEGIN');
   const inserted=await client.query(`INSERT INTO processed_webhook_events(gateway,event_id,event_type,gateway_created_at,raw_payload,status) VALUES('RAZORPAY',$1,$2,CASE WHEN $3::bigint IS NULL THEN NULL ELSE to_timestamp($3::bigint) END,$4,'PROCESSING') ON CONFLICT(gateway,event_id) DO NOTHING RETURNING id`,[eventId,p.event,p.created_at??null,raw.toString('utf8')]);
   if(!inserted.rowCount){await client.query('ROLLBACK');return res.status(200).json({status:'DUPLICATE_IGNORED'})}
   const pr=await client.query(`SELECT id,status,amount FROM payment_transactions WHERE gateway_order_id=$1 FOR UPDATE`,[payment.order_id]);
   if(!pr.rowCount){await client.query(`UPDATE processed_webhook_events SET status='UNMATCHED' WHERE gateway='RAZORPAY' AND event_id=$1`,[eventId]);await client.query('COMMIT');return res.status(202).json({status:'UNMATCHED'})}
   const row=pr.rows[0];
   if(p.event==='payment.captured' && row.status!=='CAPTURED'){
    await client.query(`UPDATE payment_transactions SET status='CAPTURED',gateway_payment_id=COALESCE(gateway_payment_id,$1),state_transition_version=state_transition_version+1,updated_at=now() WHERE id=$2`,[payment.id,row.id]);
    const j=await client.query(`INSERT INTO ledger_journals(reference_type,reference_id) VALUES('PAYMENT_CAPTURED',$1) ON CONFLICT(reference_type,reference_id) DO UPDATE SET reference_id=excluded.reference_id RETURNING journal_id`,[row.id]);
    await client.query(`SELECT process_ledger_posting($1,'BANK_RAZORPAY_AC','CUSTOMER_PAYMENT_CLEARING',$2) WHERE NOT EXISTS(SELECT 1 FROM ledger_lines WHERE journal_id=$1)`,[j.rows[0].journal_id,row.amount]);
    await client.query(`INSERT INTO outbox_events(event_id,aggregate_type,aggregate_id,event_type,payload) VALUES($1,'PAYMENT',$2,'PAYMENT_CAPTURED',$3) ON CONFLICT(event_id) DO NOTHING`,[eventId,row.id,{gatewayPaymentId:payment.id,amountPaise:String(payment.amount),orderId:payment.order_id}]);
   }
   await client.query(`UPDATE processed_webhook_events SET status='PROCESSED' WHERE gateway='RAZORPAY' AND event_id=$1`,[eventId]);
   await client.query('COMMIT');res.status(200).json({status:'PROCESSED'});
  }catch(e){await client.query('ROLLBACK').catch(()=>{});throw e}finally{client.release()}
 }catch(e){next(e)}
});
export default router;
