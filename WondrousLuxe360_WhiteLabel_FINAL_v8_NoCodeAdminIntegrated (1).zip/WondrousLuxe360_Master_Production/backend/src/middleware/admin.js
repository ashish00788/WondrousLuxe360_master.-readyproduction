import crypto from 'node:crypto';
import { env } from '../config.js';
export function requireAdmin(req,res,next){
  const provided=req.header('x-admin-key');
  if(!provided || !env.ADMIN_API_KEY) return res.status(401).json({error:'ADMIN_AUTH_REQUIRED'});
  const a=Buffer.from(provided), b=Buffer.from(env.ADMIN_API_KEY);
  if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return res.status(403).json({error:'ADMIN_FORBIDDEN'});
  next();
}
