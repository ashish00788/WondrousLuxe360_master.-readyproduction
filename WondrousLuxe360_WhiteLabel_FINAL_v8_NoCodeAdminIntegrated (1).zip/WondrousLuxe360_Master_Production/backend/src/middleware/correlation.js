import crypto from 'node:crypto';
export function correlation(req,res,next){ const id=req.header('x-correlation-id')?.slice(0,128)||`corr_${crypto.randomUUID()}`; req.correlationId=id; res.setHeader('x-correlation-id',id); next(); }
