import Decimal from 'decimal.js';
export const CALC_ENGINE_VERSION='v1.0.0-HARDENED';
// IMPORTANT: this wrapper does not define or replace the user's proprietary commission math.
// Replace calculateCommissionSlabs with the existing frozen business implementation.
export function executeCalculation(input, calculateCommissionSlabs){
  if(!Number.isSafeInteger(input.orderAmountPaise) || input.orderAmountPaise<0) throw new Error('INVALID_ORDER_AMOUNT');
  Decimal.set({precision:40,rounding:Decimal.ROUND_HALF_UP});
  const raw=calculateCommissionSlabs(input);
  const gross=new Decimal(raw.grossCommissionPaise), tds=new Decimal(raw.tdsAmountPaise), admin=new Decimal(raw.adminFeePaise), net=new Decimal(raw.netCommissionPaise);
  if(!net.eq(gross.minus(tds).minus(admin))) throw new Error('CALCULATION_INVARIANT_FAILED');
  if([gross,tds,admin,net].some(x=>!x.isFinite()||x.isNegative())) throw new Error('CALCULATION_OUTPUT_INVALID');
  return { ...raw, engineVersion:CALC_ENGINE_VERSION, inputSnapshot:structuredClone(input), timestamp:new Date().toISOString() };
}
