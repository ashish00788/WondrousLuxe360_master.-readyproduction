import Decimal from 'decimal.js';

export const GOLD_LUXURY_THEMES = Object.freeze([
  {name:'Black Gold',bg:'#0B0B0B',surface:'#171717',primary:'#D4AF37',accent:'#F5D76E',text:'#FFF8E1'},
  {name:'White Gold',bg:'#FAF8F2',surface:'#FFFFFF',primary:'#C9A227',accent:'#E8D48A',text:'#171717'},
  {name:'Royal Gold',bg:'#120B22',surface:'#20143A',primary:'#D4AF37',accent:'#BFA6FF',text:'#FFF9E8'},
  {name:'Midnight Gold',bg:'#070B14',surface:'#101827',primary:'#D4AF37',accent:'#8EA7FF',text:'#F7F1D0'},
  {name:'Champagne Gold',bg:'#241D18',surface:'#342A22',primary:'#D6B36A',accent:'#F2D9A0',text:'#FFF8E8'},
  {name:'Emerald Gold',bg:'#071A15',surface:'#0E2A22',primary:'#D4AF37',accent:'#65C6A0',text:'#F4FFF8'},
  {name:'Sapphire Gold',bg:'#07142B',surface:'#10264D',primary:'#D4AF37',accent:'#70A7FF',text:'#F3F7FF'},
  {name:'Ruby Gold',bg:'#240A12',surface:'#3A101D',primary:'#D4AF37',accent:'#FF7A92',text:'#FFF4F6'},
  {name:'Onyx Gold',bg:'#111111',surface:'#222222',primary:'#D4AF37',accent:'#B9B9B9',text:'#FFFFFF'},
  {name:'Pearl Gold',bg:'#F2EEE5',surface:'#FFFDF8',primary:'#B9922E',accent:'#E5C56A',text:'#211D16'},
  {name:'Royal Blue Gold',bg:'#08152E',surface:'#112A55',primary:'#D4AF37',accent:'#C4D7FF',text:'#F8FAFF'},
  {name:'Burgundy Gold',bg:'#210B12',surface:'#35131E',primary:'#D4AF37',accent:'#D995A6',text:'#FFF6F7'},
  {name:'Teal Gold',bg:'#071B1B',surface:'#0E2D2C',primary:'#D4AF37',accent:'#65D0C7',text:'#F2FFFE'},
  {name:'Mocha Gold',bg:'#211710',surface:'#33241A',primary:'#D4AF37',accent:'#CFA57A',text:'#FFF7EE'},
  {name:'Platinum Gold',bg:'#17191B',surface:'#292C30',primary:'#D4AF37',accent:'#D9DEE5',text:'#FFFFFF'}
]);

export const WHITE_LABEL_DEFAULTS = Object.freeze({
  calculation_base_amount: '100.00',
  currency: {code:'INR', symbol:'₹', decimals:2},
  business_tree: {enabled:true, default_trees:1, default_levels:20, admin_can_expand_levels:true, admin_can_expand_trees:true, badge_changes_do_not_create_new_tree:true},
  free_binary: {enabled:true, ratio:'1:1', depth:'UNLIMITED', bv_commission_to_shopping_pct:100},
  badges: {unlimited:true, gst_included:true, gst_pct:18, multiple_active_income:true, upgrade_preserves_previous_income:true},
  simulation: {requires_calculation_before_apply:true, versioned:true, historical_transactions_immutable:true},
  themes: {single_click_switch:true, catalog:'GOLD_LUXURY_THEMES'}
});

export function calculateFromBaseAmount(baseAmount, rules){
  const base = new Decimal(baseAmount ?? 100);
  const f = rules.financial ?? {};
  const pct = (p) => base.mul(new Decimal(p ?? 0)).div(100);
  const tds = pct(f.tds_pct);
  const admin = pct(f.admin_pct);
  const donation = pct(f.donation_pct);
  const customerExpenses = pct(f.customer_expense_pct);
  const nonWorking = pct(f.non_working_pct);
  const cash = base.mul(new Decimal(f.cash_wallet_pct ?? 80)).div(100);
  const shopping = base.mul(new Decimal(f.shopping_wallet_pct ?? 20)).div(100);
  return {base:base.toFixed(2), tds:tds.toFixed(2), admin:admin.toFixed(2), donation:donation.toFixed(2), customer_expenses:customerExpenses.toFixed(2), non_working_pool:nonWorking.toFixed(2), cash_wallet:cash.toFixed(2), shopping_wallet:shopping.toFixed(2)};
}
