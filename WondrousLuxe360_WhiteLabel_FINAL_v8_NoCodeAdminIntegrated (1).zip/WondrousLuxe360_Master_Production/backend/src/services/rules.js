import Decimal from 'decimal.js';

export const DEFAULT_RULES = Object.freeze({
  financial:{tds_pct:5,admin_pct:10,donation_pct:2,customer_expense_pct:10,non_working_pct:35,minimum_payout:500,cash_wallet_pct:80,shopping_wallet_pct:20},
  free_binary:{enabled:true,depth:'UNLIMITED',ratio_left:1,ratio_right:1,bv_to_shopping_pct:100,paid_badge_disables_free_binary:true},
  network:{default_levels:20,default_trees:1,autofill:'LEFT_TO_RIGHT_TOP_TO_BOTTOM',allow_admin_expansion:true,single_active_business_tree:true,badge_changes_do_not_create_new_tree:true},
  tax:{badge_tax_included:true,badge_tax_rate:18},
  payout:{working_cutoff:'00:00',non_working_day:10,non_working_period:'1-30'},
  currency:{base:'INR',multi_currency:true}, white_label:{calculation_base_amount:100,single_click_theme_switch:true,gold_based_themes:true}
});

export function D(v){ return new Decimal(v ?? 0); }
export function pct(amount,p){ return D(amount).mul(D(p)).div(100); }

export function validateRules(rules){
  const f=rules.financial ?? {};
  const w=D(f.cash_wallet_pct).add(D(f.shopping_wallet_pct));
  if(!w.eq(100)) throw new Error('WALLET_RATIO_MUST_EQUAL_100');
  for(const key of ['tds_pct','admin_pct','donation_pct','customer_expense_pct','non_working_pct']){
    if(D(f[key]).lt(0)||D(f[key]).gt(100)) throw new Error(`INVALID_${key.toUpperCase()}`);
  }
  if(D(f.minimum_payout).lt(0)) throw new Error('INVALID_MINIMUM_PAYOUT');
  if(!Number.isInteger(rules.network?.default_levels)||rules.network.default_levels<1) throw new Error('INVALID_LEVEL_COUNT');
  if(!Number.isInteger(rules.network?.default_trees)||rules.network.default_trees<1) throw new Error('INVALID_TREE_COUNT');
  return true;
}

export function simulateFinancials({ecommerce={},network={},rules}){
  validateRules(rules);
  const eRevenue=D(ecommerce.revenue), eCost=D(ecommerce.product_cost).add(D(ecommerce.tax)).add(D(ecommerce.shipping)).add(D(ecommerce.payment_cost)).add(D(ecommerce.discounts)).add(D(ecommerce.returns)).add(D(ecommerce.other_expenses));
  const eProfit=eRevenue.sub(eCost);
  const nBase=D(network.working_base), tds=pct(nBase,rules.financial.tds_pct), admin=pct(nBase,rules.financial.admin_pct), donation=pct(nBase,rules.financial.donation_pct), cust=pct(nBase,rules.financial.customer_expense_pct);
  const nExpenses=tds.add(admin).add(donation).add(cust);
  const nProfit=D(network.revenue).sub(nExpenses).sub(D(network.payout_liability));
  return {ecommerce:{revenue:eRevenue.toFixed(4),cost:eCost.toFixed(4),profit:eProfit.toFixed(4)},network:{revenue:D(network.revenue).toFixed(4),expenses:nExpenses.toFixed(4),payout_liability:D(network.payout_liability).toFixed(4),profit:nProfit.toFixed(4)},overall_profit:eProfit.add(nProfit).toFixed(4),rules_snapshot:rules};
}
