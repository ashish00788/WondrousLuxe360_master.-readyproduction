import crypto from 'node:crypto';
import { env } from '../config.js';
import { getBusiness, loadActiveCredentials } from './integrationManager.js';
export async function createRazorpayOrder({amountPaise,currency='INR',receipt,notes={},businessSlug='wondrousluxe360'}){
  const b=await getBusiness(businessSlug);
  const stored=await loadActiveCredentials({businessId:b.id,serviceCode:'payment',providerName:'razorpay',environment:'live'});
  const keyId=stored?.credentials?.key_id||env.RAZORPAY_KEY_ID;
  const keySecret=stored?.credentials?.key_secret||env.RAZORPAY_KEY_SECRET;
  if(!keyId||!keySecret) throw Object.assign(new Error('RAZORPAY_NOT_CONFIGURED'),{status:503});
  const auth=Buffer.from(`${keyId}:${keySecret}`).toString('base64');
  const response=await fetch('https://api.razorpay.com/v1/orders',{method:'POST',headers:{Authorization:`Basic ${auth}`,'Content-Type':'application/json'},body:JSON.stringify({amount:amountPaise,currency,receipt,notes})});
  const body=await response.json();
  if(!response.ok) throw Object.assign(new Error(body?.error?.description||'Razorpay order creation failed'),{status:502,gateway:body});
  return body;
}
export function makeGatewayOrderId(){ return `wlx_${crypto.randomUUID().replaceAll('-','').slice(0,24)}`; }
