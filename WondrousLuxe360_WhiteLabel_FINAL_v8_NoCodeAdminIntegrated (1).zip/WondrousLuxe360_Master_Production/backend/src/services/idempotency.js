import crypto from 'node:crypto';
export function requestHash(req){
  const canonical=JSON.stringify({method:req.method,path:req.originalUrl,body:req.body ?? null});
  return crypto.createHash('sha256').update(canonical).digest('hex');
}
export async function beginIdempotency(client,key,hash){
  const r=await client.query('SELECT request_hash,response_status,response_body FROM idempotency_records WHERE idempotency_key=$1 FOR UPDATE',[key]);
  if(!r.rowCount) return null;
  if(r.rows[0].request_hash!==hash){ const e=new Error('IDEMPOTENCY_CONFLICT'); e.status=409; throw e; }
  return r.rows[0];
}
