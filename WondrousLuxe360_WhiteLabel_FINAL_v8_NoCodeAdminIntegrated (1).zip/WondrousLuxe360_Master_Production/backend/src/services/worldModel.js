import Decimal from 'decimal.js';

Decimal.set({ precision: 50, rounding: Decimal.ROUND_HALF_UP });
const D = (v=0) => new Decimal(v);
const pct = (base, p) => D(base).mul(D(p)).div(100);

export function simulateWhiteLabelModel(input={}) {
  const base=D(input.baseAmount ?? 100);
  if(!base.isFinite() || base.isNegative()) throw new Error('INVALID_BASE_AMOUNT');
  const f=input.financial ?? {};
  const tds=pct(base,f.tds_pct ?? 5);
  const admin=pct(base,f.admin_pct ?? 10);
  const donation=pct(base,f.donation_pct ?? 2);
  const customer=pct(base,f.customer_expense_pct ?? 10);
  const nonWorking=pct(base,f.non_working_pct ?? 35);
  const cash=pct(base,f.cash_wallet_pct ?? 80);
  const shopping=pct(base,f.shopping_wallet_pct ?? 20);
  const ecommerce=input.ecommerce ?? {};
  const sales=D(ecommerce.sales ?? base);
  const cogs=D(ecommerce.cogs ?? 0);
  const shipping=D(ecommerce.shipping ?? 0);
  const gateway=D(ecommerce.gateway_fees ?? 0);
  const discounts=D(ecommerce.discounts ?? 0);
  const returns=D(ecommerce.returns ?? 0);
  const other=D(ecommerce.other_expenses ?? 0);
  const ecommerceProfit=sales.minus(cogs).minus(shipping).minus(gateway).minus(discounts).minus(returns).minus(other);
  const networkLiability=tds.plus(admin).plus(donation).plus(customer).plus(nonWorking);
  const networkResidual=base.minus(networkLiability);
  const overall=ecommerceProfit.plus(networkResidual);
  return {
    base:base.toFixed(2),
    network:{tds:tds.toFixed(2),admin:admin.toFixed(2),donation:donation.toFixed(2),customer_expenses:customer.toFixed(2),non_working_pool:nonWorking.toFixed(2),cash_wallet:cash.toFixed(2),shopping_wallet:shopping.toFixed(2),liability:networkLiability.toFixed(2),residual:networkResidual.toFixed(2)},
    ecommerce:{sales:sales.toFixed(2),cogs:cogs.toFixed(2),shipping:shipping.toFixed(2),gateway_fees:gateway.toFixed(2),discounts:discounts.toFixed(2),returns:returns.toFixed(2),other_expenses:other.toFixed(2),profit:ecommerceProfit.toFixed(2)},
    consolidated:{profit_or_loss:overall.toFixed(2),status:overall.isNegative()?'LOSS':overall.isZero()?'BREAK_EVEN':'PROFIT'}
  };
}

export function validateDynamicStructure({levels=20,trees=1}) {
  if(!Number.isSafeInteger(levels)||levels<1) throw new Error('INVALID_LEVELS');
  if(!Number.isSafeInteger(trees)||trees<1) throw new Error('INVALID_TREES');
  return {levels,trees};
}

export function calculateCoupon({cartValue,minCartValue=0,discountPct=0,maxDiscount=null}) {
  const cart=D(cartValue), min=D(minCartValue), pctValue=D(discountPct);
  if(cart.lt(min)) return {eligible:false,discount:'0.00'};
  let discount=pct(cart,pctValue);
  if(maxDiscount!==null) discount=Decimal.min(discount,D(maxDiscount));
  return {eligible:true,discount:discount.toFixed(2),payable:cart.minus(discount).toFixed(2)};
}
