import Decimal from 'decimal.js';

Decimal.set({ precision: 50, rounding: Decimal.ROUND_HALF_UP });
const D = (v=0) => new Decimal(v ?? 0);
const pct = (v,p) => D(v).mul(D(p)).div(100);
const money = v => D(v).toFixed(2);

export const SIMULATOR_VERSION = 'v2.0.0-white-label-lab';

export function defaultSimulationRules(overrides={}) {
  return {
    baseAmount: 100,
    badges: [100,300,500],
    gstIncludedPct: 18,
    nonWorkingPct: 35,
    nonWorkingLevels: 20,
    businessVolumeSharePct: 50,
    bvPerCurrency: 1,
    matchingRatio: '1:1',
    matchingCommissionPct: 10,
    commissionBasisThreshold: 500,
    achieversPoolPct: 10,
    otherPoolsPct: 0,
    cashWalletPct: 80,
    shoppingWalletPct: 20,
    minimumPayout: 500,
    paidDurationMonths: 3,
    workingPayoutCutoff: '00:00',
    nonWorkingPayoutDay: 10,
    nonWorkingPeriod: '1-30',
    freeBinaryEnabled: true,
    freeBinaryDepth: 'UNLIMITED',
    freeBinaryRatio: '1:1',
    paidDisablesFreeBinary: true,
    freeBinaryActivationMinLevels: 4,
    companyIds: ['COMPANY-001','COMPANY-002','COMPANY-003'],
    levels: 20,
    trees: 1,
    ...overrides
  };
}

export function validateSimulationRules(r) {
  const x = defaultSimulationRules(r);
  if (!D(x.cashWalletPct).add(D(x.shoppingWalletPct)).eq(100)) throw new Error('WALLET_RATIO_MUST_EQUAL_100');
  if (!Number.isInteger(x.nonWorkingLevels) || x.nonWorkingLevels < 1) throw new Error('INVALID_NON_WORKING_LEVELS');
  if (!Number.isInteger(x.levels) || x.levels < 1) throw new Error('INVALID_LEVELS');
  if (!Number.isInteger(x.trees) || x.trees < 1) throw new Error('INVALID_TREES');
  for (const k of ['gstIncludedPct','nonWorkingPct','businessVolumeSharePct','matchingCommissionPct','achieversPoolPct','otherPoolsPct']) {
    if (D(x[k]).lt(0) || D(x[k]).gt(100)) throw new Error(`INVALID_${k}`);
  }
  return x;
}

export function badgeBreakdown(amount, rules) {
  const r = validateSimulationRules(rules);
  const gross = D(amount);
  const taxable = gross.div(D(1).add(D(r.gstIncludedPct).div(100)));
  const gst = gross.sub(taxable);
  const nonWorkingPool = pct(gross, r.nonWorkingPct);
  const perLevel = nonWorkingPool.div(r.nonWorkingLevels);
  return { gross: money(gross), taxable: money(taxable), gst: money(gst), nonWorkingPool: money(nonWorkingPool), nonWorkingPerLevel: money(perLevel) };
}

export function matchingExample({leftBV=100,rightBV=100,rules={}}={}) {
  const r = validateSimulationRules(rules);
  const left = D(leftBV), right = D(rightBV);
  const matched = Decimal.min(left,right);
  const eligibleBV = pct(matched, r.businessVolumeSharePct);
  const commission = pct(eligibleBV, r.matchingCommissionPct);
  return {
    leftBV: money(left), rightBV: money(right), matchedBV: money(matched),
    businessVolumeUsed: money(eligibleBV), commission: money(commission),
    cashWallet: money(pct(commission,r.cashWalletPct)), shoppingWallet: money(pct(commission,r.shoppingWalletPct)),
    ratio: r.matchingRatio
  };
}

export function assignCompanySponsor({registrationIndex=1, companyIds=['COMPANY-001','COMPANY-002','COMPANY-003']}={}) {
  if (!Number.isInteger(registrationIndex) || registrationIndex < 1) throw new Error('INVALID_REGISTRATION_INDEX');
  if (!Array.isArray(companyIds) || companyIds.length < 1) throw new Error('INVALID_COMPANY_IDS');
  return companyIds[(registrationIndex-1) % companyIds.length];
}

export function generateDummyTree({memberCount=25, levels=20, companyIds=['COMPANY-001','COMPANY-002','COMPANY-003']}={}) {
  if (!Number.isInteger(memberCount) || memberCount < 1) throw new Error('INVALID_MEMBER_COUNT');
  const nodes = companyIds.map((id,i)=>({id,name:`Company Reserve ${i+1}`,sponsorId:null,parentId:null,side:i%2?'R':'L',treeNo:1,level:0,company:true}));
  const queue = [...nodes];
  let cursor = 1;
  while (cursor <= memberCount) {
    const id = `DUMMY-${String(cursor).padStart(3,'0')}`;
    const sponsor = queue[(cursor-1) % queue.length];
    const childCount = nodes.filter(n=>n.parentId===sponsor.id).length;
    const side = childCount % 2 === 0 ? 'L' : 'R';
    const level = Math.min(levels, sponsor.level + 1);
    const node = {id,name:`Dummy Member ${cursor}`,sponsorId:sponsor.id,parentId:sponsor.id,side,treeNo:1,level,company:false};
    nodes.push(node); queue.push(node); cursor++;
  }
  return nodes;
}

export function simulateTreeMigration(nodes, maxLevels=20) {
  const firstTree = nodes.filter(n => n.treeNo === 1);
  const completed = firstTree.filter(n => n.level >= maxLevels);
  const migrated = completed.map((n,i)=>({...n,treeNo:2,migrationOrder:i+1,level:0,parentId:null}));
  return { completedCount: completed.length, migratedCount: migrated.length, migrated };
}

export function simulateDuration({badges=[],asOf='2026-01-01',rules={}}={}) {
  const r = validateSimulationRules(rules);
  const now = new Date(asOf);
  return badges.map(b=>{
    const start = new Date(b.activatedAt);
    const end = new Date(start);
    end.setMonth(end.getMonth()+Number(b.durationMonths ?? r.paidDurationMonths));
    const active = now < end;
    return { badgeId:b.id, amount:money(b.amount), activatedAt:b.activatedAt, expiresAt:end.toISOString(), active, incomeStatus:active?'RUNNING':'STOPPED_REACTIVATE_REQUIRED' };
  });
}

export function simulateCompanyEconomics({badgeAmount=100,workingRevenue=1000,ecommerce={},rules={}}={}) {
  const r = validateSimulationRules(rules);
  const badge = badgeBreakdown(badgeAmount,r);
  const workRevenue = D(workingRevenue);
  const matched = matchingExample({leftBV:workRevenue,rightBV:workRevenue,rules:r});
  const workingCommission = D(matched.commission);
  const achievers = pct(workRevenue,r.achieversPoolPct);
  const otherPools = pct(workRevenue,r.otherPoolsPct);
  const nonWorking = D(badge.nonWorkingPool);
  const eRevenue = D(ecommerce.revenue ?? 0);
  const eCosts = ['productCost','tax','shipping','paymentCost','discounts','returns','otherExpenses'].reduce((s,k)=>s.add(D(ecommerce[k] ?? 0)),D(0));
  const ecommerceProfit = eRevenue.sub(eCosts);
  const companyProfit = workRevenue.add(eRevenue).sub(workingCommission).sub(achievers).sub(otherPools).sub(nonWorking).sub(eCosts);
  return {
    badge, working: {revenue:money(workRevenue), commission:money(workingCommission), achieversPool:money(achievers), otherPools:money(otherPools)},
    ecommerce:{revenue:money(eRevenue),costs:money(eCosts),profit:money(ecommerceProfit)},
    company:{profitOrLoss:money(companyProfit),status:companyProfit.gt(0)?'PROFIT':companyProfit.lt(0)?'LOSS':'BREAK_EVEN'},
    walletSplit:{cash:matched.cashWallet,shopping:matched.shoppingWallet}
  };
}

export function runFullSimulation(input={}) {
  const rules = validateSimulationRules(input.rules || {});
  const badges = rules.badges.map(amount => ({amount,id:`BADGE-${amount}`}));
  return {
    simulatorVersion: SIMULATOR_VERSION,
    rules,
    badges: badges.map(b=>({...b, breakdown:badgeBreakdown(b.amount,rules)})),
    matching: matchingExample({leftBV:input.leftBV ?? 100,rightBV:input.rightBV ?? 100,rules}),
    sponsorAssignments: Array.from({length:Math.min(input.memberCount ?? 30,30)},(_,i)=>({member:`DUMMY-${String(i+1).padStart(3,'0')}`,sponsorId:assignCompanySponsor({registrationIndex:i+1,companyIds:rules.companyIds})})),
    tree: generateDummyTree({memberCount:input.memberCount ?? 30,levels:rules.levels,companyIds:rules.companyIds}),
    durations: simulateDuration({badges:input.activeBadges || [{id:'B100',amount:100,activatedAt:'2026-01-01T00:00:00Z'},{id:'B300',amount:300,activatedAt:'2026-02-01T00:00:00Z'},{id:'B500',amount:500,activatedAt:'2026-03-01T00:00:00Z'}],asOf:input.asOf || '2026-04-01',rules}),
    economics: simulateCompanyEconomics({badgeAmount:input.badgeAmount ?? 100,workingRevenue:input.workingRevenue ?? 1000,ecommerce:input.ecommerce,rules}),
    treeMigration: simulateTreeMigration(generateDummyTree({memberCount:input.memberCount ?? 30,levels:rules.levels,companyIds:rules.companyIds}),rules.levels)
  };
}
