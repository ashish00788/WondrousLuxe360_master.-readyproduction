import crypto from 'node:crypto';
export function verifyHmac(rawBody, signature, secret){
  if (!signature || !secret) return false;
  const expected=crypto.createHmac('sha256',secret).update(rawBody).digest('hex');
  const a=Buffer.from(expected,'utf8'), b=Buffer.from(signature.trim(),'utf8');
  return a.length===b.length && crypto.timingSafeEqual(a,b);
}
