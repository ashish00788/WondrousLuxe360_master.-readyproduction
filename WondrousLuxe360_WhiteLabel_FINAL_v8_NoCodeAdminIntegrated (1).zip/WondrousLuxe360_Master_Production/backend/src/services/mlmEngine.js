import Decimal from 'decimal.js';

const D = (v=0) => new Decimal(v);
const pct = (v,p) => D(v).mul(D(p)).div(100);

export function buildDefaultMlmRules(){
  return {
    baseline_amount: 100,
    gst_pct: 18,
    bv_per_currency_unit: 1,
    business_volume_share_pct: 50,
    matching_commission_pct: 10,
    non_working_pct: 35,
    non_working_levels: 20,
    non_working_per_level_pct: 35/20,
    free_binary: { enabled:true, depth:'UNLIMITED', ratio:'1:1', bv_to_shopping_pct:100, paid_badge_disables:true, activation_condition_min_levels:4 },
    paid_duration_months: 3,
    minimum_payout: 500,
    cash_wallet_pct: 80,
    shopping_wallet_pct: 20,
    achievers_pool_pct: 10,
    other_pool_pct: 0
  };
}

export function validateMlmRules(r){
  const x={...buildDefaultMlmRules(),...r};
  if(D(x.cash_wallet_pct).add(D(x.shopping_wallet_pct)).neq(100)) throw new Error('WALLET_RATIO_MUST_EQUAL_100');
  if(D(x.non_working_pct).lt(0)||D(x.non_working_pct).gt(100)) throw new Error('INVALID_NON_WORKING_PCT');
  if(!Number.isInteger(x.non_working_levels)||x.non_working_levels<1) throw new Error('INVALID_NON_WORKING_LEVELS');
  x.non_working_per_level_pct=D(x.non_working_pct).div(x.non_working_levels).toNumber();
  return x;
}

export function simulateBinary({baseAmount=100, matchedBV=0, leftBV=0, rightBV=0, activeBadgeAmount=0, rules=buildDefaultMlmRules()}={}){
  const r=validateMlmRules(rules);
  const base=D(baseAmount), bv=D(base).mul(D(r.bv_per_currency_unit));
  const businessVolume=pct(bv,r.business_volume_share_pct);
  const matched=D(Math.min(Number(leftBV),Number(rightBV))).mul(D(1));
  const matchingCommission=pct(matched,r.matching_commission_pct);
  const nonWorkingPool=pct(activeBadgeAmount,r.non_working_pct);
  const perLevel=nonWorkingPool.div(r.non_working_levels);
  const cashWallet=pct(matchingCommission,r.cash_wallet_pct);
  const shoppingWallet=pct(matchingCommission,r.shopping_wallet_pct);
  return {
    base_amount:base.toFixed(2), bv:bv.toFixed(2), business_volume:businessVolume.toFixed(2),
    matched_bv:matched.toFixed(2), matching_commission:matchingCommission.toFixed(2),
    non_working_pool:nonWorkingPool.toFixed(2), non_working_per_level:perLevel.toFixed(2),
    cash_wallet:cashWallet.toFixed(2), shopping_wallet:shoppingWallet.toFixed(2),
    gst_included_pct:r.gst_pct, paid_duration_months:r.paid_duration_months,
    free_binary_active:!!r.free_binary.enabled
  };
}

export function buildNonWorkingSchedule(activeBadges=[], rules=buildDefaultMlmRules()){
  const r=validateMlmRules(rules);
  return activeBadges.map(b=>{
    const total=pct(b.amount,r.non_working_pct);
    const levelAmount=total.div(r.non_working_levels);
    return {badgeId:b.id, amount:D(b.amount).toFixed(2), totalPool:total.toFixed(2), perLevel:levelAmount.toFixed(4), levels:r.non_working_levels};
  });
}
