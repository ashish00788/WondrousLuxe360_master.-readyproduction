export const SERVICE_CATALOG = Object.freeze({
  payments: ['payment_gateway','payouts','refunds','upi_collect','payment_links'],
  utilities: ['mobile_recharge','bbps_billpay','electricity','gas_booking','dth','broadband','landline','water_bill','municipal_tax','fastag_recharge'],
  travel: ['flight','hotel','bus','train','metro','car_rental','cab','holiday_packages','activities','travel_insurance'],
  logistics: ['multi_carrier','courier','last_mile_10_30_min','warehouse','reverse_logistics'],
  geo: ['maps','geocoding','distance_matrix','places','pincode','route_eta','address_validation'],
  communication: ['sms','email','whatsapp','push_notifications','voice_otp'],
  identity: ['pan_verification','aadhaar_kyc','bank_account_verification','gstin_verification','business_kyc'],
  commerce: ['gst_invoice','e_invoice','shipping_rates','tax_calculation','product_catalog','reviews','loyalty','gift_cards','coupons'],
  ai: ['customer_chat','recommendations','faq_generation','translation'],
  finance: ['currency_fx','forex_rates','bank_statement','accounting_export'],
  marketplace: ['vendor_onboarding','vendor_payout','franchise','affiliate_tracking'],
  support: ['ticketing','crm','helpdesk']
});

export const ALL_SERVICE_CODES = Object.freeze(
  [...new Set(Object.values(SERVICE_CATALOG).flat())]
);

export function isServiceCode(code){
  return ALL_SERVICE_CODES.includes(code);
}
