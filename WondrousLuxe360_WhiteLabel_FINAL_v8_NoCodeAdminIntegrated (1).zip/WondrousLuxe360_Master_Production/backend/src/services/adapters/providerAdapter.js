export class ProviderAdapter {
  constructor({serviceCode, providerName, baseUrl, apiKey, authType='bearer', timeoutMs=15000, headers={}}={}){
    this.serviceCode=serviceCode;
    this.providerName=providerName;
    this.baseUrl=baseUrl;
    this.apiKey=apiKey;
    this.authType=authType;
    this.timeoutMs=timeoutMs;
    this.headers=headers;
  }
  configured(){ return Boolean(this.baseUrl && this.apiKey); }
  authHeaders(){
    if(this.authType==='x-api-key') return {'X-API-Key':this.apiKey};
    if(this.authType==='api-key') return {'Api-Key':this.apiKey};
    if(this.authType==='basic') return {'Authorization':`Basic ${this.apiKey}`};
    if(this.authType==='none') return {};
    return {'Authorization':`Bearer ${this.apiKey}`};
  }
  async request(path,{method='GET',body,headers={}}={}){
    if(!this.configured()) throw Object.assign(new Error('PROVIDER_NOT_CONFIGURED'),{status:503});
    const controller=new AbortController(); const t=setTimeout(()=>controller.abort(),this.timeoutMs);
    try{
      const url=new URL(path,this.baseUrl);
      const res=await fetch(url,{method,signal:controller.signal,headers:{'Content-Type':'application/json',...this.authHeaders(),...this.headers,...headers},body:body===undefined?undefined:JSON.stringify(body)});
      const text=await res.text(); let data; try{data=JSON.parse(text)}catch{data={raw:text}};
      if(!res.ok) throw Object.assign(new Error('PROVIDER_REQUEST_FAILED'),{status:502,providerStatus:res.status,data});
      return data;
    }finally{clearTimeout(t)}
  }
}

export function adapterFromEnv(code){
  const key=code.toUpperCase().replace(/[^A-Z0-9]/g,'_');
  return new ProviderAdapter({
    serviceCode:code,
    providerName:process.env[`${key}_PROVIDER`]||'',
    baseUrl:process.env[`${key}_BASE_URL`]||'',
    apiKey:process.env[`${key}_API_KEY`]||'',
    authType:process.env[`${key}_AUTH_TYPE`]||'bearer',
    timeoutMs:Number(process.env[`${key}_TIMEOUT_MS`]||15000)
  });
}
