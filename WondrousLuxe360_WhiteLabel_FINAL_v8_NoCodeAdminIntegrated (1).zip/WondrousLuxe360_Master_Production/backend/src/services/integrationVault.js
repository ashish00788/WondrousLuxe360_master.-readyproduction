import crypto from 'node:crypto';
import { env } from '../config.js';

const ALGO='aes-256-gcm';
const VERSION='v1';

function masterKey(){
  const raw=env.INTEGRATION_ENCRYPTION_KEY;
  if(!raw) throw Object.assign(new Error('INTEGRATION_ENCRYPTION_KEY_REQUIRED'),{status:503});
  const key=Buffer.from(raw,'hex');
  if(key.length!==32) throw Object.assign(new Error('INTEGRATION_ENCRYPTION_KEY_INVALID'),{status:503});
  return key;
}

export function encryptCredentials(value){
  const iv=crypto.randomBytes(12);
  const cipher=crypto.createCipheriv(ALGO,masterKey(),iv);
  const ciphertext=Buffer.concat([cipher.update(JSON.stringify(value),'utf8'),cipher.final()]);
  const tag=cipher.getAuthTag();
  return [VERSION,iv.toString('base64url'),tag.toString('base64url'),ciphertext.toString('base64url')].join('.');
}

export function decryptCredentials(payload){
  const [version,ivB64,tagB64,dataB64]=String(payload||'').split('.');
  if(version!==VERSION||!ivB64||!tagB64||!dataB64) throw Object.assign(new Error('INVALID_ENCRYPTED_CREDENTIALS'),{status:500});
  const decipher=crypto.createDecipheriv(ALGO,masterKey(),Buffer.from(ivB64,'base64url'));
  decipher.setAuthTag(Buffer.from(tagB64,'base64url'));
  const clear=Buffer.concat([decipher.update(Buffer.from(dataB64,'base64url')),decipher.final()]).toString('utf8');
  return JSON.parse(clear);
}

export function fingerprintCredentials(value){
  return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
}

export function maskCredentials(value){
  const out={};
  for(const [k,v] of Object.entries(value||{})){
    if(v===null||v===undefined){out[k]=v;continue;}
    const s=String(v);
    out[k]=s.length<=6?'••••••':`${s.slice(0,3)}••••${s.slice(-3)}`;
  }
  return out;
}
