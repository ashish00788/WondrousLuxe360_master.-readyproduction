import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool } from '../db.js';
import { encryptCredentials, decryptCredentials, fingerprintCredentials, maskCredentials } from './integrationVault.js';
import { ProviderAdapter } from './adapters/providerAdapter.js';

const here=path.dirname(fileURLToPath(import.meta.url));
const catalog=JSON.parse(fs.readFileSync(path.join(here,'../../../../config/integration-provider-catalog.json'),'utf8'));

export function providerDefinition(name){ return catalog.providers[name]||null; }
export function providerCatalog(){ return Object.entries(catalog.providers).map(([id,v])=>({id,...v})); }

export async function getBusiness(slug='wondrousluxe360'){
  const q=await pool.query('SELECT * FROM businesses WHERE slug=$1 AND is_active=true',[slug]);
  if(!q.rowCount) throw Object.assign(new Error('BUSINESS_NOT_FOUND'),{status:404});
  return q.rows[0];
}

export async function listIntegrations(businessId){
  const q=await pool.query(`SELECT id,service_code,provider_name,environment,config,active,verification_status,last_tested_at,last_error,credential_fingerprint,created_at,updated_at FROM integration_credentials WHERE business_id=$1 ORDER BY service_code,provider_name,environment`,[businessId]);
  return q.rows;
}

export async function saveIntegration({businessId,serviceCode,providerName,environment='sandbox',credentials,config={},active=false}){
  const def=providerDefinition(providerName);
  if(!def) throw Object.assign(new Error('UNSUPPORTED_PROVIDER'),{status:400});
  if(!credentials || typeof credentials!=='object') throw Object.assign(new Error('INVALID_CREDENTIALS'),{status:400});
  const encrypted=encryptCredentials(credentials);
  const fp=fingerprintCredentials(credentials);
  const q=await pool.query(`INSERT INTO integration_credentials(business_id,service_code,provider_name,environment,config,encrypted_credentials,credential_fingerprint,active,verification_status,last_error) VALUES($1,$2,$3,$4,$5,$6,$7,$8,'UNTESTED',NULL) ON CONFLICT(business_id,service_code,provider_name,environment) DO UPDATE SET config=EXCLUDED.config,encrypted_credentials=EXCLUDED.encrypted_credentials,credential_fingerprint=EXCLUDED.credential_fingerprint,active=EXCLUDED.active,verification_status='UNTESTED',last_tested_at=NULL,last_error=NULL,updated_at=now() RETURNING id,service_code,provider_name,environment,config,active,verification_status,last_tested_at,last_error,credential_fingerprint,updated_at`,[businessId,serviceCode,providerName,environment,config,encrypted,fp,active]);
  return q.rows[0];
}

export async function setActive({businessId,id,active}){
  const q=await pool.query(`UPDATE integration_credentials SET active=$1,updated_at=now() WHERE id=$2 AND business_id=$3 AND (verification_status='VERIFIED' OR $1=false) RETURNING id,service_code,provider_name,environment,active,verification_status`,[active,id,businessId]);
  if(!q.rowCount) throw Object.assign(new Error(active?'INTEGRATION_MUST_BE_VERIFIED':'INTEGRATION_NOT_FOUND'),{status:active?409:404});
  return q.rows[0];
}

export async function loadActiveCredentials({businessId,serviceCode,providerName=null,environment='live'}){
  const args=[businessId,serviceCode,environment];
  let sql=`SELECT * FROM integration_credentials WHERE business_id=$1 AND service_code=$2 AND environment=$3 AND active=true`;
  if(providerName){args.push(providerName);sql+=' AND provider_name=$4';}
  sql+=' ORDER BY updated_at DESC LIMIT 1';
  const q=await pool.query(sql,args);
  if(!q.rowCount) return null;
  const row=q.rows[0];
  return {...row,credentials:decryptCredentials(row.encrypted_credentials)};
}

export function publicIntegration(row){
  return {...row,credential_fingerprint:row.credential_fingerprint?`${row.credential_fingerprint.slice(0,8)}…`:null};
}

export function maskedCredentials(credentials){ return maskCredentials(credentials); }

export async function adapterFromIntegration({businessId,serviceCode,environment='live',providerName=null}){
  const stored=await loadActiveCredentials({businessId,serviceCode,providerName,environment});
  if(!stored) return null;
  const def=providerDefinition(stored.provider_name);
  const c=stored.credentials||{};
  let authType=stored.config?.authType||def?.authType||'bearer';
  let apiKey=c.api_key||c.access_token||c.token||c.key||'';
  let headers=stored.config?.headers||{};
  if(authType==='basic'){
    const user=c.key_id||c.api_key||c.username||c.email||'';
    const secret=c.key_secret||c.api_token||c.password||'';
    apiKey=Buffer.from(`${user}:${secret}`).toString('base64');
    authType='basic';
  }
  return {
    adapter:new ProviderAdapter({serviceCode,providerName:stored.provider_name,baseUrl:stored.config?.baseUrl||def?.baseUrl||'',apiKey,authType,timeoutMs:Number(stored.config?.timeoutMs||15000),headers}),
    stored,credentials:c,definition:def
  };
}


export async function testIntegration({businessId,id}){
  const q=await pool.query('SELECT * FROM integration_credentials WHERE id=$1 AND business_id=$2',[id,businessId]);
  if(!q.rowCount) throw Object.assign(new Error('INTEGRATION_NOT_FOUND'),{status:404});
  const row=q.rows[0]; const def=providerDefinition(row.provider_name);
  const credentials=decryptCredentials(row.encrypted_credentials);
  let status='CONFIGURED_NOT_VERIFIED', error=null;
  try{
    if(!row.config?.baseUrl && !def.baseUrl) throw new Error('PROVIDER_BASE_URL_REQUIRED');
    const baseUrl=row.config?.baseUrl||def.baseUrl;
    const u=new URL(baseUrl);
    if(!['https:'].includes(u.protocol)) throw new Error('HTTPS_REQUIRED');
    if(def.authType==='basic'){
      const a=Buffer.from(`${credentials.key_id||credentials.api_key||credentials.email||''}:${credentials.key_secret||credentials.api_token||credentials.password||''}`).toString('base64');
      const pathValue=row.config?.testPath||def.testPath;
      if(!pathValue) throw new Error('TEST_PATH_REQUIRED');
      const r=await fetch(new URL(pathValue,baseUrl),{headers:{Authorization:`Basic ${a}`,Accept:'application/json'},signal:AbortSignal.timeout(10000)});
      if(!r.ok) throw new Error(`PROVIDER_HTTP_${r.status}`);
      status='VERIFIED';
    } else if(def.authType==='query-api-key'){
      const pathValue=row.config?.testPath||def.testPath;
      if(!pathValue) throw new Error('TEST_PATH_REQUIRED');
      const testUrl=new URL(pathValue,baseUrl); testUrl.searchParams.set('key',credentials.api_key||'');
      const r=await fetch(testUrl,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(10000)});
      if(!r.ok) throw new Error(`PROVIDER_HTTP_${r.status}`);
      status='VERIFIED';
    } else if(def.authType==='x-api-key' || def.authType==='bearer' || def.authType==='api-key'){
      const pathValue=row.config?.testPath||def.testPath;
      if(!pathValue) throw new Error('TEST_PATH_REQUIRED');
      const headers={Accept:'application/json'};
      if(def.authType==='x-api-key') headers['X-API-Key']=credentials.api_key||'';
      else if(def.authType==='api-key') headers['Api-Key']=credentials.api_key||'';
      else headers.Authorization=`Bearer ${credentials.api_key||''}`;
      const r=await fetch(new URL(pathValue,baseUrl),{headers,signal:AbortSignal.timeout(10000)});
      if(!r.ok) throw new Error(`PROVIDER_HTTP_${r.status}`);
      status='VERIFIED';
    } else {
      status='CONFIGURED_NOT_VERIFIED';
    }
  }catch(e){ error=e.message||'CONNECTION_TEST_FAILED'; status='FAILED'; }
  const updated=await pool.query(`UPDATE integration_credentials SET verification_status=$1,last_tested_at=now(),last_error=$2,updated_at=now() WHERE id=$3 AND business_id=$4 RETURNING id,service_code,provider_name,environment,active,verification_status,last_tested_at,last_error,credential_fingerprint`,[status,error,id,businessId]);
  return updated.rows[0];
}
