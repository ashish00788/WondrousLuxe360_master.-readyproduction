import crypto from 'node:crypto';
import { env } from '../config.js';

function auth(){
  if(!env.RAZORPAY_KEY_ID || !env.RAZORPAY_KEY_SECRET) throw Object.assign(new Error('RAZORPAY_NOT_CONFIGURED'),{status:503});
  return Buffer.from(`${env.RAZORPAY_KEY_ID}:${env.RAZORPAY_KEY_SECRET}`).toString('base64');
}
async function call(path,method='GET',body,idempotencyKey){
  const headers={Authorization:`Basic ${auth()}`,'Content-Type':'application/json'};
  if(idempotencyKey) headers['X-Payout-Idempotency']=idempotencyKey;
  const r=await fetch(`https://api.razorpay.com/v1${path}`,{method,headers,body:body?JSON.stringify(body):undefined});
  const b=await r.json().catch(()=>({}));
  if(!r.ok) throw Object.assign(new Error(b?.error?.description||'RAZORPAY_X_ERROR'),{status:502,gateway:b});
  return b;
}
export const createContact=(body)=>call('/contacts','POST',body);
export const createFundAccount=(body)=>call('/fund_accounts','POST',body);
export const createPayout=(body,idempotencyKey=crypto.randomUUID())=>call('/payouts','POST',body,idempotencyKey);
export const fetchPayout=(id)=>call(`/payouts/${encodeURIComponent(id)}`);
export const cancelPayout=(id)=>call(`/payouts/${encodeURIComponent(id)}`,'PATCH',{status:'cancelled'});
