import test from 'node:test';
import assert from 'node:assert/strict';
import { verifyHmac } from '../src/services/hmac.js';
import crypto from 'node:crypto';
test('webhook HMAC accepts exact signature',()=>{const body='{"event":"payment.captured"}',secret='test-secret';const sig=crypto.createHmac('sha256',secret).update(body).digest('hex');assert.equal(verifyHmac(Buffer.from(body),sig,secret),true);assert.equal(verifyHmac(Buffer.from(body),sig.slice(0,-1),secret),false);});
