import test from 'node:test';
import assert from 'node:assert/strict';
import { executeCalculation } from '../src/services/calculationEngine.js';
test('hardened wrapper preserves injected calculation output',()=>{
 const calc=({orderAmountPaise})=>({grossCommissionPaise:orderAmountPaise/10,tdsAmountPaise:orderAmountPaise/100,adminFeePaise:orderAmountPaise/100,netCommissionPaise:orderAmountPaise*0.08});
 const out=executeCalculation({orderAmountPaise:100000,level:1,rank:'TEST',ruleVersion:'1'},calc);
 assert.equal(out.netCommissionPaise,8000); assert.equal(out.engineVersion,'v1.0.0-HARDENED');
});
