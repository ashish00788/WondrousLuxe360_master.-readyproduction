import test from 'node:test';
import assert from 'node:assert/strict';
import { simulateBinary, buildNonWorkingSchedule } from '../src/services/mlmEngine.js';

test('latest ₹100 baseline',()=>{
 const r=simulateBinary({baseAmount:100,leftBV:100,rightBV:100,activeBadgeAmount:100});
 assert.equal(r.bv,'100.00'); assert.equal(r.business_volume,'50.00'); assert.equal(r.matching_commission,'10.00'); assert.equal(r.non_working_pool,'35.00'); assert.equal(r.non_working_per_level,'1.7500');
});
test('35 percent is equally distributed across 20 levels',()=>{
 const s=buildNonWorkingSchedule([{id:'B1',amount:100}]); assert.equal(s[0].perLevel,'1.7500'); assert.equal(s[0].levels,20);
});
