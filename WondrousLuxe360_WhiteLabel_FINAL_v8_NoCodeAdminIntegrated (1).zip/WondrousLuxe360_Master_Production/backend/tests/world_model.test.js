import test from 'node:test';
import assert from 'node:assert/strict';
import { simulateWhiteLabelModel, calculateCoupon, validateDynamicStructure } from '../src/services/worldModel.js';

test('₹100 baseline is deterministic',()=>{
 const r=simulateWhiteLabelModel({baseAmount:100,financial:{tds_pct:5,admin_pct:10,donation_pct:2,customer_expense_pct:10,non_working_pct:35,cash_wallet_pct:80,shopping_wallet_pct:20},ecommerce:{sales:100,cogs:20}});
 assert.equal(r.network.tds,'5.00'); assert.equal(r.network.non_working_pool,'35.00'); assert.equal(r.network.cash_wallet,'80.00'); assert.equal(r.network.shopping_wallet,'20.00'); assert.equal(r.ecommerce.profit,'80.00');
});
test('coupon slab calculation is deterministic',()=>{const r=calculateCoupon({cartValue:500,minCartValue:500,discountPct:10});assert.equal(r.discount,'50.00');assert.equal(r.payable,'450.00')});
test('dynamic structure allows 30 levels and 20 trees',()=>assert.deepEqual(validateDynamicStructure({levels:30,trees:20}),{levels:30,trees:20}));
