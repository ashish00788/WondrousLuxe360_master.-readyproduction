BEGIN;

-- Registration identity uniqueness: store only deterministic hashes for PAN/mobile uniqueness.
CREATE TABLE IF NOT EXISTS member_identity (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  pan_hash CHAR(64),
  mobile_hash CHAR(64),
  email_hash CHAR(64),
  profile JSONB NOT NULL DEFAULT '{}'::jsonb,
  nominee JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_member_identity_pan ON member_identity(pan_hash) WHERE pan_hash IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_member_identity_mobile ON member_identity(mobile_hash) WHERE mobile_hash IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_member_identity_email ON member_identity(email_hash) WHERE email_hash IS NOT NULL;

-- Generic white-label provider catalog. Credentials never belong in this table.
CREATE TABLE IF NOT EXISTS service_providers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  service_code TEXT NOT NULL,
  provider_name TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'ADAPTER',
  config JSONB NOT NULL DEFAULT '{}'::jsonb,
  commission_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(business_id,service_code,provider_name)
);

-- Unified bookings/orders for travel + utilities; provider-specific payload stays isolated.
CREATE TABLE IF NOT EXISTS service_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
  service_code TEXT NOT NULL,
  provider_name TEXT,
  external_reference TEXT,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  gross_amount NUMERIC(20,4) NOT NULL DEFAULT 0,
  provider_cost NUMERIC(20,4) NOT NULL DEFAULT 0,
  commission_amount NUMERIC(20,4) NOT NULL DEFAULT 0,
  tax_amount NUMERIC(20,4) NOT NULL DEFAULT 0,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_service_orders_user ON service_orders(business_id,user_id,created_at DESC);

-- FAQ templates are editable; generated answers should be reviewed before publication.
CREATE TABLE IF NOT EXISTS faq_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  locale VARCHAR(16) NOT NULL DEFAULT 'en-IN',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INT NOT NULL DEFAULT 0
);

-- Footer and app-home public metrics already have a separate configuration table;
-- keep the same source of truth but allow placement blocks.
CREATE TABLE IF NOT EXISTS ui_content_blocks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  placement TEXT NOT NULL,
  code TEXT NOT NULL,
  content JSONB NOT NULL DEFAULT '{}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(business_id,placement,code)
);

-- Vendor media slots: 7-8 images + one marketing video by default, limits remain badge-configurable.
CREATE TABLE IF NOT EXISTS vendor_media_policy (
  business_id UUID PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  max_product_images INT NOT NULL DEFAULT 8 CHECK(max_product_images >= 1),
  max_marketing_videos INT NOT NULL DEFAULT 1 CHECK(max_marketing_videos >= 0),
  badge_limits JSONB NOT NULL DEFAULT '{}'::jsonb
);

-- Donation transparency aggregates, without exposing donor PII publicly.
CREATE TABLE IF NOT EXISTS donation_aggregates (
  business_id UUID PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  donor_count BIGINT NOT NULL DEFAULT 0 CHECK(donor_count >= 0),
  total_donated NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(total_donated >= 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMIT;
