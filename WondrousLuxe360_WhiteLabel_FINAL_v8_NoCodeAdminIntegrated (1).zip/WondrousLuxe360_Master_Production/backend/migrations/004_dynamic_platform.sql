BEGIN;

CREATE TABLE IF NOT EXISTS businesses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  country_code CHAR(2) NOT NULL DEFAULT 'IN',
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  timezone TEXT NOT NULL DEFAULT 'Asia/Kolkata',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS business_settings (
  business_id UUID PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  settings JSONB NOT NULL DEFAULT '{}'::jsonb,
  version INT NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS rule_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  version_no BIGINT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('DRAFT','SIMULATED','APPROVED','ACTIVE','RETIRED')),
  rules JSONB NOT NULL,
  simulation JSONB,
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  approved_at TIMESTAMPTZ,
  effective_at TIMESTAMPTZ,
  UNIQUE(business_id, version_no)
);

CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  sku TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  image_url TEXT,
  cost NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(cost>=0),
  price NUMERIC(20,4) NOT NULL CHECK(price>=0),
  tax_rate NUMERIC(7,4) NOT NULL DEFAULT 0 CHECK(tax_rate>=0),
  bv NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(bv>=0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(business_id, sku)
);

CREATE TABLE IF NOT EXISTS coupons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  min_cart_value NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(min_cart_value>=0),
  discount_pct NUMERIC(7,4) NOT NULL CHECK(discount_pct>=0 AND discount_pct<=100),
  max_discount NUMERIC(20,4),
  starts_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ,
  usage_limit INT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(business_id, code)
);

CREATE TABLE IF NOT EXISTS network_structures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  structure_type TEXT NOT NULL CHECK(structure_type IN ('FREE_BINARY','WORKING_BINARY','NON_WORKING_BINARY','LEADERSHIP')),
  max_levels INT NOT NULL DEFAULT 20 CHECK(max_levels>=1),
  max_trees INT NOT NULL DEFAULT 1 CHECK(max_trees>=1),
  placement_policy JSONB NOT NULL DEFAULT '{"direction":"LEFT_TO_RIGHT","order":"TOP_TO_BOTTOM"}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS network_positions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  structure_id UUID NOT NULL REFERENCES network_structures(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  tree_no INT NOT NULL CHECK(tree_no>=1),
  level_no INT NOT NULL CHECK(level_no>=1),
  parent_position_id UUID REFERENCES network_positions(id) ON DELETE RESTRICT,
  left_position_id UUID REFERENCES network_positions(id) ON DELETE RESTRICT,
  right_position_id UUID REFERENCES network_positions(id) ON DELETE RESTRICT,
  sponsor_user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
  cycle_no INT NOT NULL DEFAULT 1 CHECK(cycle_no>=1),
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','COMPLETED','INACTIVE')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(structure_id, tree_no, user_id, cycle_no)
);

CREATE TABLE IF NOT EXISTS badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  color TEXT NOT NULL DEFAULT '#D4AF37',
  icon_url TEXT,
  product_image_url TEXT,
  product_description TEXT,
  activation_amount NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(activation_amount>=0),
  tax_included BOOLEAN NOT NULL DEFAULT TRUE,
  tax_rate NUMERIC(7,4) NOT NULL DEFAULT 18 CHECK(tax_rate>=0),
  non_working_pct NUMERIC(7,4) NOT NULL DEFAULT 35 CHECK(non_working_pct>=0 AND non_working_pct<=100),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  badge_id UUID NOT NULL REFERENCES badges(id) ON DELETE RESTRICT,
  activated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','EXPIRED','SUSPENDED')),
  activation_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS leadership_ranks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  image_url TEXT,
  color TEXT,
  personal_volume_pct NUMERIC(7,4) NOT NULL DEFAULT 50,
  business_volume_pct NUMERIC(7,4) NOT NULL DEFAULT 50,
  other_pools_pct NUMERIC(7,4) NOT NULL DEFAULT 10,
  royalty_pct NUMERIC(7,4) NOT NULL DEFAULT 1,
  qualification_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS user_ranks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  rank_id UUID NOT NULL REFERENCES leadership_ranks(id) ON DELETE RESTRICT,
  achieved_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(user_id, rank_id)
);

CREATE TABLE IF NOT EXISTS engagement_campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK(kind IN ('CHECKIN','SPIN','QUIZ','STREAK','OFFER','CUSTOM')),
  config JSONB NOT NULL DEFAULT '{}'::jsonb,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS marketing_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK(kind IN ('VISITING_CARD','WELCOME_LETTER','PAMPHLET','BROCHURE','CUSTOM')),
  template JSONB NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS payout_batches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  payout_type TEXT NOT NULL CHECK(payout_type IN ('WORKING_DAILY','NON_WORKING_MONTHLY','CUSTOM')),
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  cutoff_at TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'CALCULATED' CHECK(status IN ('CALCULATED','APPROVED','PROCESSING','PAID','FAILED','CANCELLED')),
  calculation_snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS financial_pools (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  pool_type TEXT NOT NULL DEFAULT 'CUSTOM',
  source_rule JSONB NOT NULL DEFAULT '{}'::jsonb,
  distribution_rule JSONB NOT NULL DEFAULT '{}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX IF NOT EXISTS idx_positions_structure_tree_level ON network_positions(structure_id,tree_no,level_no);
CREATE INDEX IF NOT EXISTS idx_user_badges_user_status ON user_badges(user_id,status);
CREATE INDEX IF NOT EXISTS idx_user_ranks_active ON user_ranks(user_id,active);
CREATE INDEX IF NOT EXISTS idx_payout_batches_period ON payout_batches(business_id,payout_type,period_start,period_end);

INSERT INTO businesses(name,slug,country_code,currency)
VALUES('WondrousLuxe360','wondrousluxe360','IN','INR')
ON CONFLICT(slug) DO NOTHING;

INSERT INTO business_settings(business_id,settings)
SELECT id, jsonb_build_object(
  'financial', jsonb_build_object('tds_pct',5,'admin_pct',10,'donation_pct',2,'customer_expense_pct',10,'non_working_pct',35,'minimum_payout',500,'cash_wallet_pct',80,'shopping_wallet_pct',20),
  'free_binary', jsonb_build_object('enabled',true,'depth','UNLIMITED','ratio_left',1,'ratio_right',1,'bv_to_shopping_pct',100,'paid_badge_disables_free_binary',true),
  'network', jsonb_build_object('default_levels',20,'default_trees',1,'autofill','LEFT_TO_RIGHT_TOP_TO_BOTTOM','allow_admin_expansion',true),
  'tax', jsonb_build_object('badge_tax_included',true,'badge_tax_rate',18),
  'payout', jsonb_build_object('working_cutoff','00:00','non_working_day',10,'non_working_period','1-30'),
  'currency', jsonb_build_object('base','INR','multi_currency',true)
)
FROM businesses WHERE slug='wondrousluxe360'
ON CONFLICT(business_id) DO NOTHING;

COMMIT;

-- Extended white-label/e-commerce profile and presentation layer
CREATE TABLE IF NOT EXISTS user_profiles (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  full_name TEXT,
  mobile TEXT,
  email TEXT,
  address_line1 TEXT,
  address_line2 TEXT,
  city TEXT,
  state TEXT,
  postal_code TEXT,
  country_code CHAR(2),
  avatar_url TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS themes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  config JSONB NOT NULL DEFAULT '{}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS inventory_items (
  product_id UUID PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE,
  quantity NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(quantity>=0),
  reserved_quantity NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(reserved_quantity>=0),
  reorder_level NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(reorder_level>=0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
  order_no TEXT NOT NULL,
  currency CHAR(3) NOT NULL,
  subtotal NUMERIC(20,4) NOT NULL DEFAULT 0,
  discount NUMERIC(20,4) NOT NULL DEFAULT 0,
  tax NUMERIC(20,4) NOT NULL DEFAULT 0,
  shipping NUMERIC(20,4) NOT NULL DEFAULT 0,
  total NUMERIC(20,4) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'CREATED' CHECK(status IN ('CREATED','PAID','PROCESSING','SHIPPED','DELIVERED','CANCELLED','REFUNDED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(business_id, order_no)
);

CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  quantity NUMERIC(20,4) NOT NULL CHECK(quantity>0),
  unit_price NUMERIC(20,4) NOT NULL CHECK(unit_price>=0),
  unit_cost NUMERIC(20,4) NOT NULL CHECK(unit_cost>=0),
  bv NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(bv>=0)
);

CREATE TABLE IF NOT EXISTS shopping_coupons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  source_type TEXT NOT NULL CHECK(source_type IN ('BV','CAMPAIGN','ADMIN','OTHER')),
  source_id TEXT,
  coupon_id UUID REFERENCES coupons(id) ON DELETE RESTRICT,
  value NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(value>=0),
  expires_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'ISSUED' CHECK(status IN ('ISSUED','REDEEMED','EXPIRED','CANCELLED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS business_volume_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  source_user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
  order_id UUID REFERENCES orders(id) ON DELETE RESTRICT,
  volume_type TEXT NOT NULL CHECK(volume_type IN ('PERSONAL','BUSINESS','FREE_BINARY','WORKING')),
  amount NUMERIC(20,4) NOT NULL CHECK(amount>=0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_bv_user_created ON business_volume_events(user_id,created_at);
CREATE INDEX IF NOT EXISTS idx_orders_user_created ON orders(user_id,created_at);

INSERT INTO themes(business_id,name,config,active)
SELECT id,'Wondrous Gold','{"primary":"#D4AF37","background":"#121212","surface":"#1E1E1E","accent":"#F5D76E","font":"serif"}'::jsonb,true
FROM businesses WHERE slug='wondrousluxe360'
AND NOT EXISTS (SELECT 1 FROM themes t WHERE t.business_id=businesses.id);


-- Default luxury theme catalog; Admin may edit/disable or add unlimited custom themes.
INSERT INTO themes(business_id,name,config,active)
SELECT b.id, v.name, v.config::jsonb, FALSE
FROM businesses b
CROSS JOIN (VALUES
('Royal Gold','{"primary":"#D4AF37","background":"#0B0B0B","surface":"#1A1A1A","accent":"#F5D76E"}'),
('Champagne Luxe','{"primary":"#F7E7CE","background":"#111111","surface":"#24201C","accent":"#D4AF37"}'),
('Black Diamond','{"primary":"#C9A227","background":"#050505","surface":"#151515","accent":"#E8D690"}'),
('Emerald Gold','{"primary":"#C9A227","background":"#07130F","surface":"#10251C","accent":"#5CCB8A"}'),
('Sapphire Gold','{"primary":"#D4AF37","background":"#07111F","surface":"#10213A","accent":"#72A8FF"}'),
('Ruby Gold','{"primary":"#D4AF37","background":"#180707","surface":"#2A1010","accent":"#FF6B6B"}'),
('Platinum Noir','{"primary":"#E5E4E2","background":"#090909","surface":"#1B1B1B","accent":"#BFC3C7"}'),
('Pearl Luxe','{"primary":"#C8A951","background":"#F7F4EE","surface":"#FFFFFF","accent":"#8C6F2D"}'),
('Royal Purple','{"primary":"#D4AF37","background":"#10091B","surface":"#211334","accent":"#B78CFF"}'),
('Ocean Gold','{"primary":"#D4AF37","background":"#06171A","surface":"#0D292E","accent":"#57D3D9"}'),
('Midnight Gold','{"primary":"#D4AF37","background":"#080B14","surface":"#151A29","accent":"#E7C766"}'),
('Copper Luxe','{"primary":"#B87333","background":"#110C08","surface":"#241710","accent":"#E0A06A"}'),
('Rose Gold','{"primary":"#B76E79","background":"#140B0D","surface":"#251417","accent":"#F3B6C0"}'),
('Ivory Gold','{"primary":"#C7A85A","background":"#F1EDE2","surface":"#FFFDF8","accent":"#6E5620"}'),
('Onyx Gold','{"primary":"#D4AF37","background":"#020202","surface":"#0D0D0D","accent":"#FFF0A6"}')
) AS v(name,config) ON TRUE
WHERE b.slug='wondrousluxe360'
AND NOT EXISTS (SELECT 1 FROM themes t WHERE t.business_id=b.id AND t.name=v.name);

INSERT INTO marketing_templates(business_id,name,kind,template)
SELECT b.id,v.name,v.kind,v.template::jsonb
FROM businesses b
CROSS JOIN (VALUES
('Member Visiting Card','VISITING_CARD','{"fields":["full_name","mobile","email","address","member_id","username"],"format":"A4"}'),
('Welcome Letter','WELCOME_LETTER','{"fields":["full_name","member_id","username","badge"],"format":"A4"}'),
('Marketing Pamphlet','PAMPHLET','{"fields":["full_name","mobile","email","referral_code"],"format":"A4"}'),
('Business Brochure','BROCHURE','{"fields":["business_name","products","contact","website"],"format":"A4"}')
) AS v(name,kind,template) ON TRUE
WHERE b.slug='wondrousluxe360'
AND NOT EXISTS (SELECT 1 FROM marketing_templates m WHERE m.business_id=b.id AND m.name=v.name);
