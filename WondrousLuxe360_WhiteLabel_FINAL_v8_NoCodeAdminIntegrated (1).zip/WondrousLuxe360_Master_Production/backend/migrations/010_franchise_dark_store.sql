BEGIN;

-- Franchise master: commercial terms remain admin-configurable and are snapshotted per agreement.
CREATE TABLE IF NOT EXISTS franchises (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  applicant_user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  franchise_code TEXT NOT NULL,
  store_name TEXT NOT NULL,
  franchise_type TEXT NOT NULL DEFAULT 'STANDARD',
  territory JSONB NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'APPLICATION',
  fee NUMERIC(20,4) NOT NULL DEFAULT 0,
  security_deposit NUMERIC(20,4) NOT NULL DEFAULT 0,
  commission_rule JSONB NOT NULL DEFAULT '{}',
  duration_months INT NOT NULL DEFAULT 12,
  renewal_rule JSONB NOT NULL DEFAULT '{}',
  kyc_snapshot JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(business_id,franchise_code)
);
CREATE INDEX IF NOT EXISTS idx_franchises_business_status ON franchises(business_id,status);

CREATE TABLE IF NOT EXISTS franchise_contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  franchise_id UUID NOT NULL REFERENCES franchises(id) ON DELETE CASCADE,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  terms_snapshot JSONB NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Dark-store / local fulfillment nodes. A franchise may own or operate a node.
CREATE TABLE IF NOT EXISTS fulfillment_nodes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  franchise_id UUID REFERENCES franchises(id) ON DELETE SET NULL,
  node_code TEXT NOT NULL,
  name TEXT NOT NULL,
  node_type TEXT NOT NULL DEFAULT 'DARK_STORE',
  address JSONB NOT NULL DEFAULT '{}',
  latitude NUMERIC(10,7),
  longitude NUMERIC(10,7),
  service_radius_km NUMERIC(10,2) NOT NULL DEFAULT 5,
  min_eta_minutes INT NOT NULL DEFAULT 10,
  max_eta_minutes INT NOT NULL DEFAULT 30,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(business_id,node_code),
  CHECK(min_eta_minutes >= 1 AND max_eta_minutes >= min_eta_minutes)
);
CREATE INDEX IF NOT EXISTS idx_fulfillment_nodes_geo ON fulfillment_nodes(business_id,is_active);

CREATE TABLE IF NOT EXISTS fulfillment_inventory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  node_id UUID NOT NULL REFERENCES fulfillment_nodes(id) ON DELETE CASCADE,
  product_id UUID,
  sku TEXT NOT NULL,
  quantity NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(quantity >= 0),
  reserved_quantity NUMERIC(20,4) NOT NULL DEFAULT 0 CHECK(reserved_quantity >= 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(node_id,sku)
);

CREATE TABLE IF NOT EXISTS delivery_zones (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  node_id UUID NOT NULL REFERENCES fulfillment_nodes(id) ON DELETE CASCADE,
  zone_code TEXT NOT NULL,
  polygon JSONB,
  postal_codes JSONB NOT NULL DEFAULT '[]',
  delivery_fee NUMERIC(20,4) NOT NULL DEFAULT 0,
  surge_rule JSONB NOT NULL DEFAULT '{}',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(node_id,zone_code)
);

CREATE TABLE IF NOT EXISTS delivery_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  node_id UUID REFERENCES fulfillment_nodes(id) ON DELETE SET NULL,
  service_order_id UUID REFERENCES service_orders(id) ON DELETE SET NULL,
  courier_provider TEXT,
  external_reference TEXT,
  status TEXT NOT NULL DEFAULT 'CREATED',
  promised_min_minutes INT,
  promised_max_minutes INT,
  pickup_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  tracking_payload JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_delivery_jobs_status ON delivery_jobs(business_id,status,created_at DESC);

-- Admin-controlled franchise defaults and local delivery policy.
CREATE TABLE IF NOT EXISTS franchise_policy (
  business_id UUID PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  application_fee NUMERIC(20,4) NOT NULL DEFAULT 0,
  security_deposit NUMERIC(20,4) NOT NULL DEFAULT 0,
  default_duration_months INT NOT NULL DEFAULT 12,
  commission_rule JSONB NOT NULL DEFAULT '{}',
  territory_rule JSONB NOT NULL DEFAULT '{}',
  dark_store_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  default_eta_min INT NOT NULL DEFAULT 10,
  default_eta_max INT NOT NULL DEFAULT 30,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMIT;
