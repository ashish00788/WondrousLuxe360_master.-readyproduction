BEGIN;
CREATE TABLE IF NOT EXISTS service_catalog (
  code TEXT PRIMARY KEY,
  category TEXT NOT NULL,
  display_name TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  provider_required BOOLEAN NOT NULL DEFAULT TRUE,
  commission_rule JSONB NOT NULL DEFAULT '{}'::jsonb,
  config JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS service_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE RESTRICT,
  service_code TEXT NOT NULL,
  provider_name TEXT,
  external_reference TEXT,
  action TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'INITIATED',
  request_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  response_payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  gross_amount NUMERIC(20,4) NOT NULL DEFAULT 0,
  provider_cost NUMERIC(20,4) NOT NULL DEFAULT 0,
  commission_amount NUMERIC(20,4) NOT NULL DEFAULT 0,
  tax_amount NUMERIC(20,4) NOT NULL DEFAULT 0,
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_service_transactions_user ON service_transactions(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_service_transactions_service ON service_transactions(service_code,created_at DESC);
COMMIT;
