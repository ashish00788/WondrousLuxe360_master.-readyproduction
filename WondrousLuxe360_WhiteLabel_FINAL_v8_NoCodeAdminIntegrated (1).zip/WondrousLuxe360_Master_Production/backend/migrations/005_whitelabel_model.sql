BEGIN;

ALTER TABLE business_settings
  ADD COLUMN IF NOT EXISTS calculation_base_amount NUMERIC(20,4) NOT NULL DEFAULT 100;

UPDATE business_settings bs
SET calculation_base_amount = COALESCE(NULLIF(bs.settings->>'calculation_base_amount','')::numeric, 100),
    settings = bs.settings || jsonb_build_object(
      'calculation_base_amount', 100,
      'business_tree', jsonb_build_object('single_active_tree', true, 'default_levels', 20, 'default_trees', 1, 'admin_can_expand_levels', true, 'admin_can_expand_trees', true, 'badge_changes_do_not_create_new_tree', true),
      'white_label', jsonb_build_object('single_click_theme_switch', true, 'gold_based_themes', true)
    );

INSERT INTO themes(business_id,name,config,active)
SELECT b.id, v.name, jsonb_build_object('background',v.bg,'surface',v.surface,'primary',v.primary,'accent',v.accent,'text',v.text,'gold_based',true),
       v.name='Black Gold'
FROM businesses b
CROSS JOIN (VALUES
 ('Black Gold','#0B0B0B','#171717','#D4AF37','#F5D76E','#FFF8E1'),
 ('White Gold','#FAF8F2','#FFFFFF','#C9A227','#E8D48A','#171717'),
 ('Royal Gold','#120B22','#20143A','#D4AF37','#BFA6FF','#FFF9E8'),
 ('Midnight Gold','#070B14','#101827','#D4AF37','#8EA7FF','#F7F1D0'),
 ('Champagne Gold','#241D18','#342A22','#D6B36A','#F2D9A0','#FFF8E8'),
 ('Emerald Gold','#071A15','#0E2A22','#D4AF37','#65C6A0','#F4FFF8'),
 ('Sapphire Gold','#07142B','#10264D','#D4AF37','#70A7FF','#F3F7FF'),
 ('Ruby Gold','#240A12','#3A101D','#D4AF37','#FF7A92','#FFF4F6'),
 ('Onyx Gold','#111111','#222222','#D4AF37','#B9B9B9','#FFFFFF'),
 ('Pearl Gold','#F2EEE5','#FFFDF8','#B9922E','#E5C56A','#211D16'),
 ('Royal Blue Gold','#08152E','#112A55','#D4AF37','#C4D7FF','#F8FAFF'),
 ('Burgundy Gold','#210B12','#35131E','#D4AF37','#D995A6','#FFF6F7'),
 ('Teal Gold','#071B1B','#0E2D2C','#D4AF37','#65D0C7','#F2FFFE'),
 ('Mocha Gold','#211710','#33241A','#D4AF37','#CFA57A','#FFF7EE'),
 ('Platinum Gold','#17191B','#292C30','#D4AF37','#D9DEE5','#FFFFFF')
) AS v(name,bg,surface,primary,accent,text)
ON CONFLICT DO NOTHING;

COMMIT;
