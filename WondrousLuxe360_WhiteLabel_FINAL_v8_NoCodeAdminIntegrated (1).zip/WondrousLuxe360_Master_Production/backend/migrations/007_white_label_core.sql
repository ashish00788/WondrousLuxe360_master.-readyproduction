BEGIN;

-- White-label tenant/business identity and independently editable presentation.
CREATE TABLE IF NOT EXISTS white_label_profiles (
  business_id UUID PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  legal_name TEXT,
  logo_url TEXT,
  favicon_url TEXT,
  primary_domain TEXT,
  support_email TEXT,
  support_phone TEXT,
  address JSONB NOT NULL DEFAULT '{}'::jsonb,
  social_links JSONB NOT NULL DEFAULT '{}'::jsonb,
  seo JSONB NOT NULL DEFAULT '{}'::jsonb,
  active_theme_id UUID,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS white_label_modules (
  business_id UUID PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  modules JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS white_label_calculation_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  base_amount NUMERIC(20,4) NOT NULL DEFAULT 100 CHECK(base_amount > 0),
  currency CHAR(3) NOT NULL DEFAULT 'INR',
  financial_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  ecommerce_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  network_rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN ('DRAFT','SIMULATED','APPROVED','ACTIVE','ARCHIVED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_calc_profiles_business_status
ON white_label_calculation_profiles(business_id,status);

-- Explicit cycle identity: same permanent user ID can occupy successive trees.
CREATE TABLE IF NOT EXISTS network_cycles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  structure_id UUID NOT NULL REFERENCES network_structures(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  cycle_no INT NOT NULL CHECK(cycle_no >= 1),
  source_cycle_id UUID REFERENCES network_cycles(id) ON DELETE RESTRICT,
  source_tree_no INT,
  target_tree_no INT NOT NULL CHECK(target_tree_no >= 1),
  completion_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'OPEN' CHECK(status IN ('OPEN','COMPLETED','ROLLED_FORWARD','CANCELLED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(structure_id,user_id,cycle_no)
);

-- Sponsored genealogy is distinct from placement genealogy.
CREATE TABLE IF NOT EXISTS sponsored_relationships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  sponsor_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  sponsored_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  depth INT NOT NULL DEFAULT 1 CHECK(depth >= 1),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(business_id,sponsor_user_id,sponsored_user_id)
);

CREATE INDEX IF NOT EXISTS idx_sponsor_rel_sponsor ON sponsored_relationships(business_id,sponsor_user_id);
CREATE INDEX IF NOT EXISTS idx_sponsor_rel_sponsored ON sponsored_relationships(business_id,sponsored_user_id);

-- Badge eligibility snapshots prevent later configuration edits from rewriting history.
CREATE TABLE IF NOT EXISTS badge_eligibility_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  earning_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  beneficiary_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  badge_id UUID NOT NULL REFERENCES badges(id) ON DELETE RESTRICT,
  earning_event_id TEXT NOT NULL,
  eligible BOOLEAN NOT NULL,
  cutoff_at TIMESTAMPTZ NOT NULL,
  snapshot JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Generic benefit/pool engine; names are presentation labels, IDs remain stable.
CREATE TABLE IF NOT EXISTS benefit_pools (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  display_name TEXT NOT NULL,
  pool_type TEXT NOT NULL DEFAULT 'CUSTOM',
  rules JSONB NOT NULL DEFAULT '{}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(business_id,code)
);

-- Customer-visible footer/app statistics use the same data source but separate placement.
CREATE TABLE IF NOT EXISTS public_metric_configs (
  business_id UUID PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  footer_config JSONB NOT NULL DEFAULT '{}'::jsonb,
  app_home_config JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Country-aware service/geo configuration, including postal-code and delivery providers.
CREATE TABLE IF NOT EXISTS geo_service_configs (
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  country_code CHAR(2) NOT NULL,
  provider TEXT,
  config JSONB NOT NULL DEFAULT '{}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  PRIMARY KEY(business_id,country_code)
);

-- Billing/invoice configuration is tenant controlled; invoice records remain immutable.
CREATE TABLE IF NOT EXISTS billing_configs (
  business_id UUID PRIMARY KEY REFERENCES businesses(id) ON DELETE CASCADE,
  invoice_prefix TEXT NOT NULL DEFAULT 'INV',
  numbering_policy JSONB NOT NULL DEFAULT '{"mode":"SEQUENTIAL"}'::jsonb,
  tax_policy JSONB NOT NULL DEFAULT '{}'::jsonb,
  payment_terms JSONB NOT NULL DEFAULT '{}'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);


INSERT INTO white_label_profiles(business_id,display_name,legal_name,active_theme_id)
SELECT b.id,b.name,b.name,t.id
FROM businesses b
LEFT JOIN LATERAL (
  SELECT id FROM themes WHERE business_id=b.id ORDER BY active DESC, created_at ASC LIMIT 1
) t ON TRUE
WHERE b.slug='wondrousluxe360'
ON CONFLICT(business_id) DO NOTHING;

INSERT INTO white_label_modules(business_id,modules)
SELECT b.id, '{
  "ecommerce":{"enabled":true,"multivendor":true,"search":true,"cart":true,"checkout":true,"inventory":true,"shipping":true,"returns":true,"refunds":true,"coupons":true,"vouchers":true,"gst_invoices":true,"bulk_product_upload":true},
  "free_binary":{"enabled":true},
  "working_binary":{"enabled":true},
  "non_working_binary":{"enabled":true},
  "leadership":{"enabled":true,"sponsored_team_separate":true},
  "engagement":{"enabled":true,"checkin":true,"spin":true,"quiz":true,"streaks":true,"offers":true},
  "customer_support":{"enabled":true,"tickets":true,"faq":true,"ai_chat":true},
  "franchise":{"enabled":true},"billing":{"enabled":true},"marketing_kit":{"enabled":true},
  "public_statistics":{"enabled":true},"social_sharing":{"enabled":true},"geo_services":{"enabled":true},
  "multi_currency":{"enabled":true},"white_label":{"enabled":true}
}'::jsonb
FROM businesses b WHERE b.slug='wondrousluxe360'
ON CONFLICT(business_id) DO NOTHING;

INSERT INTO white_label_calculation_profiles(
 business_id,name,base_amount,currency,financial_rules,network_rules,status
)
SELECT b.id,'Baseline ₹100',100,'INR',
'{"tds_pct":5,"admin_pct":10,"donation_pct":2,"customer_expense_pct":10,"non_working_pct":35,"minimum_payout":500,"cash_wallet_pct":80,"shopping_wallet_pct":20}'::jsonb,
'{"default_levels":20,"default_trees":1,"admin_can_expand_levels":true,"admin_can_expand_trees":true,"badge_changes_do_not_create_new_tree":true}'::jsonb,
'DRAFT'
FROM businesses b WHERE b.slug='wondrousluxe360'
AND NOT EXISTS (
 SELECT 1 FROM white_label_calculation_profiles p
 WHERE p.business_id=b.id AND p.name='Baseline ₹100'
);

COMMIT;
