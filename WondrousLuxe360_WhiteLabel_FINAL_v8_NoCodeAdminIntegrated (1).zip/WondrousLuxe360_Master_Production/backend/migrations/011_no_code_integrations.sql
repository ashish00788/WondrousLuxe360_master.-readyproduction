BEGIN;

CREATE TABLE IF NOT EXISTS integration_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  service_code TEXT NOT NULL,
  provider_name TEXT NOT NULL,
  environment TEXT NOT NULL DEFAULT 'sandbox' CHECK(environment IN ('sandbox','live')),
  config JSONB NOT NULL DEFAULT '{}'::jsonb,
  encrypted_credentials TEXT NOT NULL,
  credential_fingerprint CHAR(64) NOT NULL,
  active BOOLEAN NOT NULL DEFAULT FALSE,
  verification_status TEXT NOT NULL DEFAULT 'UNTESTED' CHECK(verification_status IN ('UNTESTED','VERIFIED','FAILED','CONFIGURED_NOT_VERIFIED')),
  last_tested_at TIMESTAMPTZ,
  last_error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(business_id,service_code,provider_name,environment)
);

CREATE INDEX IF NOT EXISTS idx_integration_credentials_business_service
  ON integration_credentials(business_id,service_code,active);

CREATE TABLE IF NOT EXISTS integration_webhooks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  service_code TEXT NOT NULL,
  provider_name TEXT NOT NULL,
  environment TEXT NOT NULL CHECK(environment IN ('sandbox','live')),
  event_path TEXT,
  signing_secret_encrypted TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(business_id,service_code,provider_name,environment)
);

GRANT SELECT,INSERT,UPDATE ON integration_credentials,integration_webhooks TO app_runtime;

COMMIT;
