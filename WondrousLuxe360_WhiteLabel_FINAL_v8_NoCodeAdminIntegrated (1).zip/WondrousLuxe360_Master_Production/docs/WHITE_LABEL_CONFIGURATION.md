# White-Label Business Model Configuration

This build treats the platform as a configurable business-model engine rather than a fixed brand.

## What is configurable after deployment

- Business/brand/legal display name, domain, logo and contact information
- Gold-based luxury theme, with single-click theme selection
- E-commerce modules and feature switches
- Free Binary: 1:1, unlimited depth, shopping-only BV benefit
- Working/Non-Working/Leadership structures
- Default 20 levels and 1 tree, with Admin expansion
- Badge names, images, colors, products, tax-inclusive pricing and benefit rules
- Multiple active badges and preservation of prior badge income
- Leadership rank names/images and qualification rules
- Custom pools/clubs
- Coupons, vouchers, expiry and eligibility
- E-commerce pricing/cost/tax/shipping/returns parameters
- Country, currency, timezone and provider configuration
- Customer engagement campaigns
- Marketing/document templates
- Vendor/member limits and marketplace settings
- Franchise settings
- Public statistics and footer/app-home placement
- Support/FAQ/AI-chat configuration

## Calculation model

The default simulation base is INR 100. This is only a baseline and is editable.

Admin workflow:
1. Create/edit a calculation profile.
2. Simulate it.
3. Review E-commerce P&L, Network P&L and Consolidated P&L.
4. Approve/publish the version.
5. Later create a new version and compare it.
6. Restore a previous configuration for future transactions if required.

Historical ledger records must remain immutable and linked to the rule version that produced them.

## Identity and cycles

Permanent user identity is separate from placement position and cycle. A completed cycle may create the user's next tree position with the same permanent user ID. Sponsored genealogy is stored separately from binary placement genealogy.

## Important deployment boundary

This is a production-candidate white-label configuration layer. It does not make third-party payment, tax, shipping, maps, AI, messaging or government filing services live by itself. Provider credentials, webhooks, allowlists, contracts and jurisdiction-specific compliance must be configured and tested in staging before real-money launch.
