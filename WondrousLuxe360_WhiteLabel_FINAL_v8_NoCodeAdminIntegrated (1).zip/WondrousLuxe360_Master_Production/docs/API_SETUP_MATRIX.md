# API Setup Matrix

The application now contains a provider-adapter layer for every requested service. It does **not** invent or embed third-party credentials. Each adapter becomes live only after the business purchases/contracts that provider and supplies credentials through the secure No-Code Admin Integration Manager or, for bootstrap/legacy integrations, server environment variables/secret manager.

## Payment
- Razorpay order creation + payment verification + signed webhook + idempotency.

## Utilities
- Mobile recharge
- BBPS bill payment
- Gas booking
- Electricity
- DTH
- Broadband

## Travel
- Flight
- Hotel
- Bus
- Car rental
- Holiday packages

## Geo / delivery
- Maps, geocoding, distance matrix, places, pincode
- Multi-carrier shipping
- Optional 10–30 minute last-mile adapter

## Communication
- SMS, email, WhatsApp

## Tax / billing
- GST invoice and e-invoice provider adapters

## AI
- Customer chat and recommendation adapters

## Important
A provider adapter is an integration point, not a purchased API. Commercial agreements, credentials, sandbox testing, rate limits, country coverage and legal/tax compliance must be completed with the chosen provider before production.
