# Franchise + Dark Store / 10-30 Minute Delivery

This release adds a real database/API layer for the franchise model and local dark-store fulfillment.

## Franchise
- Application, approval, franchise code, territory, fee, security deposit, duration and commission snapshot.
- Admin controls commercial policy without changing application code.
- Franchise can be attached to a fulfillment node.

## Dark Store
- Fulfillment nodes with franchise ownership, geo coordinates and service radius.
- Local SKU inventory and reservation quantities.
- Delivery zones, postal-code coverage, fees and surge rules.
- Delivery jobs with courier provider, external reference, status and tracking payload.
- Configurable 10-30 minute ETA; actual live ETA requires the contracted last-mile provider and map/routing credentials.

## API
- `POST /api/v1/franchise/apply`
- `GET /api/v1/franchise/policy`
- Admin: `POST /api/v1/franchise/admin/policy`
- Admin: `POST /api/v1/franchise/admin/approve`
- Admin: `GET /api/v1/franchise/admin/list`
- `GET /api/v1/fulfillment/nodes`
- `POST /api/v1/fulfillment/eta`
- Admin: `POST /api/v1/fulfillment/admin/nodes`
- Admin: `POST /api/v1/fulfillment/admin/inventory`
- Admin: `POST /api/v1/fulfillment/admin/zones`
- Admin: `POST /api/v1/fulfillment/admin/jobs`
- Admin: `GET /api/v1/fulfillment/admin/jobs`
