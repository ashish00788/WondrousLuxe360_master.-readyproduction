# Production go/no-go checklist

- [ ] Replace proprietary commission adapter with the approved implementation.
- [ ] Generate 100+ frozen golden vectors from the approved engine.
- [ ] Run migrations on staging and verify constraints/triggers.
- [ ] Configure Razorpay production webhook URL and secret.
- [ ] Verify duplicate, out-of-order and retry webhooks.
- [ ] Verify concurrent refund race handling.
- [ ] Verify payment/gateway reconciliation.
- [ ] Configure TLS and domain.
- [ ] Configure PITR backups and perform a restore drill.
- [ ] Configure centralized logs, metrics and alerts.
- [ ] Run load/concurrency/chaos/security tests.
- [ ] Enable admin MFA/RBAC/maker-checker in the admin service.
- [ ] Confirm privacy/KYC retention and deletion policies with legal/compliance professionals.
- [ ] Production GO only after all required checks pass.

## Dynamic Platform additions
- [ ] Configure real authentication/authorization and role-based admin permissions.
- [ ] Configure production payment gateway(s) and payout provider(s); verify webhooks end-to-end.
- [ ] Attach and independently test the approved 20-level business mathematics and all configured badge/working/non-working rules.
- [ ] Complete E-Commerce order/inventory/shipping/tax/refund workflows and country-specific compliance.
- [ ] Complete PDF rendering/storage for visiting cards, welcome letters and marketing materials.
- [ ] Complete background workers for daily and monthly payout batches, notifications, coupon expiry and outbox processing.
- [ ] Run load, concurrency, security, recovery and penetration tests before real-money launch.
