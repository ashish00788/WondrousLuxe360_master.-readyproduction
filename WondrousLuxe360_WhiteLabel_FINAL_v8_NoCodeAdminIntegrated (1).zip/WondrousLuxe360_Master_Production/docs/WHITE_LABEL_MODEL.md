# WondrousLuxe360 White-Label Business Model

## Core baseline
- Calculation base amount: configurable; default ₹100.
- One active business tree is the default entry structure. Badge activation/upgrade does not create a separate tree.
- Default level count is 20, but Admin may expand levels and tree count through versioned configuration.
- Free Binary is separate: 1:1, unlimited depth, BV benefit to Shopping only, fully configurable.
- Paid Badge rules, Working/Non-Working rules, E-Commerce rules, ranks, clubs and pools are configuration entities, not hard-coded names.
- Every configuration change must be simulated and versioned before activation.
- Historical ledger transactions remain immutable.

## Themes
The platform ships with 15 gold-based luxury themes and single-click theme switching. Theme identity is presentation-only and must never alter financial calculations.

## Calculation Studio
Admin can enter one base amount (default 100), calculate the current model, edit any configurable figure, simulate again, compare P&L, then apply or restore a version.

The calculation engine must use exact decimal arithmetic; no floating-point money calculations are permitted.
