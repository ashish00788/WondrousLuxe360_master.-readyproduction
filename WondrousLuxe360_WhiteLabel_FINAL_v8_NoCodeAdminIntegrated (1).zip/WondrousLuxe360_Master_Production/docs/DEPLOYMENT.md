# Server deployment

Recommended Linux server: Docker Engine + Compose, firewall permitting only SSH and HTTPS. Keep PostgreSQL private; do not expose port 5432 publicly.

Use a domain and TLS reverse proxy. The included Nginx config is a baseline only and should be placed behind a real TLS configuration before public launch.
