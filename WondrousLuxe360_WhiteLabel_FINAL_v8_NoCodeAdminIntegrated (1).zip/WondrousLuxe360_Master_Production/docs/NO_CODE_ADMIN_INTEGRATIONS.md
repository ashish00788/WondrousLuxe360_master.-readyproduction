# No-Code Admin Integration System

Added in release 8.x consolidation.

## Admin
Open `/admin/integrations` behind the normal admin network/auth controls. The page lets an authorized admin select a supported provider, enter credentials, save them encrypted, test the connection, and activate/deactivate the integration.

## Security
- Credentials are encrypted with AES-256-GCM using `INTEGRATION_ENCRYPTION_KEY`.
- Full secrets are never returned by API responses.
- Activation is allowed only after a successful verification for providers that expose a test endpoint.
- Every save should be auditable; secret values are never written to audit metadata.
- The browser never receives the encryption key.

## Important boundary
No-code means no code changes for supported/configurable providers. A provider with a unique OAuth/signing/booking contract may still require a one-time adapter implementation. The system does not fabricate provider credentials or claim a provider is live merely because credentials were stored.

## Production
Set `INTEGRATION_ENCRYPTION_KEY` to a random 32-byte hex value and keep it in a server-side secret manager. Do not commit it to Git.
