# Payment / Payout Hardening

The build separates customer payment collection from outbound payouts.

- Payment orders require an idempotency key.
- Checkout signatures are verified server-side.
- Razorpay payment webhooks use the raw request body for HMAC validation.
- Duplicate webhook event IDs are ignored transactionally.
- Payment capture creates an immutable ledger journal.
- Payout requests have their own idempotency key and immutable eligibility snapshot.
- RazorpayX payouts require the merchant account to satisfy Razorpay's current allowlisting and idempotency requirements.
- Payout webhooks must update payout state; they must never create a second payout.
- Daily/monthly payout jobs must calculate and freeze a batch before any gateway call.
- Never store gateway secrets in source control.

Razorpay's current documentation states that payout requests require an idempotency key and IP allowlisting, and that payout status webhooks should be used for state updates. Payment webhooks must be verified against the raw request body.

Live gateway tests require the merchant's sandbox credentials and public webhook endpoint; code-only tests cannot prove a live gateway account is configured correctly.
