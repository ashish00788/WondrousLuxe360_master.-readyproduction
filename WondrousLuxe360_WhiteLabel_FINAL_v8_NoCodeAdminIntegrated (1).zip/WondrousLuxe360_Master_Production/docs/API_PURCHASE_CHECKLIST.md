# White-Label Provider Purchase Checklist

The codebase uses adapters and environment variables. Provider credentials are intentionally not committed.

## Required / recommended provider categories

1. Payment gateway: Razorpay (already scaffolded)
2. Travel inventory: flight + hotel + bus aggregator/wholesaler API
3. Utility/recharge: BBPS-compatible provider for recharge and bill payment
4. Maps/geo: maps + geocoding + places + distance + pincode
5. Notifications: SMS + WhatsApp + transactional email
6. GST/e-invoice: authorized IRP/GSP integration where legally applicable
7. Shipping: multi-carrier shipping/last-mile provider
8. AI: customer support/recommendation provider (optional)
9. Media storage/CDN: object storage + CDN for vendor/product media
10. Identity/KYC: PAN/KYC verification provider if required by the business workflow

## Commercial rules

Provider commissions are never hard-coded. Each service has provider cost, customer price,
commission %, fixed fee, taxes, effective dates and currency in the Admin calculation profile.

## Important

Travel and utility providers differ by country and commercial agreement. Choose a provider
after confirming API coverage, booking/cancellation support, settlement terms, SLA, rate limits,
sandbox availability and licensing/compliance for your target countries.


## No-Code Admin
After purchase/approval, supported provider credentials can be entered from `/admin/integrations`; they are encrypted at rest and activated only after connection testing. Legacy env-based adapters remain as a fallback during migration.
