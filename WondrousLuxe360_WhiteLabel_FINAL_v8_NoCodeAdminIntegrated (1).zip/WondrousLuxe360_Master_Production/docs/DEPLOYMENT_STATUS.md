# Deployment status

This package is a production-candidate architecture, not a claim of universal certification.

Before real-money launch:
1. Install dependencies with `npm ci` in backend.
2. Run migrations.
3. Run `npm test` and `npm run preflight`.
4. Configure a staging gateway account.
5. Expose a TLS webhook endpoint.
6. Test payment create -> checkout -> signature verify -> webhook -> ledger -> refund.
7. Test payout batch -> gateway -> payout webhook -> reconciliation.
8. Run load, security and disaster-recovery tests.
9. Configure country-specific tax/legal rules.
10. Only then switch to live credentials.
