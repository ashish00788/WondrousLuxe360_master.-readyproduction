# WondrousLuxe360 — Final Business Logic Baseline

This document freezes the currently supplied business rules. Missing legal/tax values remain configurable and must be reviewed before production use.

## Free Binary
- Registration gift.
- 1:1 binary.
- Unlimited depth.
- Fully dynamic.
- Qualifying purchase generates Business Volume (BV).
- BV benefit is shopping-only; default 100% of eligible BV benefit is configurable.
- No cash conversion for Free Binary BV.
- Configurable shopping coupons with minimum cart slabs and expiry.
- Paid Badge activation disables Free Binary income eligibility automatically; ordinary E-Commerce offers/engagement remain separately configurable.

## Paid Network
- Baseline: 20 levels / 1 tree.
- Admin may expand levels and trees subject to infrastructure/compliance limits.
- Binary AutoFill baseline: left-to-right, top-to-bottom.
- 5% TDS, 10% Admin allocation, 2% donation, 10% other customer expenses, 35% non-working pool, ₹500 minimum payout, 80/20 cash/shopping wallet split are preserved as supplied baseline rules.
- Non-working pool: 35% of each activated badge amount, distributed across configured levels. It is not a second source of income.
- Multiple active badges remain simultaneously active; upgrading does not erase earlier badge income.
- Working payout is a daily batch with a midnight cutoff. Eligibility is snapshotted before payout.
- Non-working payout is monthly, based on the 1st–30th business period, generated on the 10th.

## Leadership
- Leadership genealogy is separate from non-working payout genealogy.
- Personal Volume default 50%, Business Volume default 50%, Other Pools default 10%, Royalty default 1% (all Admin configurable).
- Rank names/images/qualification rules are dynamic.
- Top achievers/top earners are generated from verified records; public income display must respect consent and applicable law.

## E-Commerce
- Products, inventory, cart/checkout, tax, shipping, payment costs, coupons/vouchers, returns/refunds, engagement campaigns, and margins are configurable.
- E-Commerce P&L and Network P&L remain separate, with an optional consolidated view.

## Admin Financial Control
- Edit → Simulate → P&L/risk check → Approve → Version → Apply.
- Historical ledger entries are immutable; configuration changes apply prospectively.
- Restore changes future configuration only; it does not rewrite historical financial records.

## White-label / Worldwide
- Business, branding, country, currency, timezone, tax and payment configuration are tenant-scoped.
- Currency support is configurable; jurisdiction-specific tax and direct-selling/payment rules must be validated before launch.
