# WondrousLuxe360 White-Label Final Scope

## Core model
- One business tree is the default active business tree; admin can create additional trees and increase level count.
- Default baseline is 20 levels and 1 tree.
- Tree/cycle identity is separate from user identity.
- A completed cycle can create the next tree position using the same permanent user ID.
- Historical transactions remain tied to the rule version that produced them.

## Separate structures
- E-commerce
- Free Binary (1:1, unlimited depth, shopping-only BV benefit)
- Working Binary
- Non-working Binary
- Sponsored leadership network
- Ranks
- Badges
- Custom pools

## Financial studio
- Base amount defaults to INR 100 and is editable.
- Decimal arithmetic is used for deterministic calculations.
- E-commerce P&L and Network P&L are calculated separately, with a consolidated view.
- Simulation is required before a rule version is activated.
- Version restore changes future rules only; historical ledger entries remain immutable.

## Commerce scope
Catalog, search, filters, cart, checkout, inventory, vendor stores, bulk upload, product media, shipping, returns/refunds, coupons/vouchers, invoices, tax snapshots, customer support, FAQ, referral links, engagement campaigns, franchise applications, public statistics, marketing templates and country/currency configuration are modeled as configurable modules.

## Vendor scope
A vendor may also be a platform member. Vendor badge rules can determine product upload limits. Vendor media supports multiple images and a marketing video. Marketplace settlement must remain separate from member/network income.

## Internationalization
Country, currency, timezone, tax and payment configuration are tenant-specific. Country-specific legal/compliance rules must be reviewed before launch.

## Data protection
No software can truthfully guarantee that data can "never" be copied. The build should use least-privilege access, encryption in transit/at rest, secret management, signed URLs, audit logs, database permissions, backups, monitoring and tenant isolation to materially reduce unauthorized copying/exfiltration.
