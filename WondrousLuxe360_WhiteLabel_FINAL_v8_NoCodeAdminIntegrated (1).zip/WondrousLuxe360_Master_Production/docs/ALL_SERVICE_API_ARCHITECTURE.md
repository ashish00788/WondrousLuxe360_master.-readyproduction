# All-Service API Architecture

This release provides a single provider-adapter layer for the platform's common service categories:

- Payments: payment gateway, payouts, refunds, UPI collect, payment links
- Utilities: mobile recharge, BBPS, electricity, gas, DTH, broadband, landline, water, municipal tax, FASTag
- Travel: flight, hotel, bus, train, metro, car rental, cab, holidays, activities, travel insurance
- Logistics: multi-carrier, courier, last-mile 10–30 minute delivery, warehouse, reverse logistics
- Geo: maps, geocoding, distance matrix, places, pincode, ETA, address validation
- Communication: SMS, email, WhatsApp, push, voice OTP
- Identity/KYC: PAN, Aadhaar KYC, bank verification, GSTIN, business KYC
- Commerce: GST invoice, e-invoice, shipping rates, tax, catalog, reviews, loyalty, gift cards, coupons
- AI: customer chat, recommendations, FAQ generation, translation
- Finance: FX, forex rates, bank statement, accounting export
- Marketplace: vendor onboarding, vendor payout, franchise, affiliate tracking
- Support: ticketing, CRM, helpdesk

The code intentionally does not contain fabricated third-party credentials or pretend that a provider is live. Each provider must be contracted and its exact API base URL, authentication, endpoints, limits, settlement rules and compliance requirements configured in the environment. The adapter supports configurable authentication and action paths so a provider can be swapped without changing business logic.

Endpoint family:
- GET /api/v1/platform-services/catalog
- GET /api/v1/platform-services/status
- POST /api/v1/platform-services/:serviceCode/search
- POST /api/v1/platform-services/:serviceCode/quote
- POST /api/v1/platform-services/:serviceCode/validate
- POST /api/v1/platform-services/:serviceCode/book
- POST /api/v1/platform-services/:serviceCode/pay
- POST /api/v1/platform-services/:serviceCode/cancel
- POST /api/v1/platform-services/:serviceCode/status
- POST /api/v1/platform-services/:serviceCode/refund

These are orchestration endpoints, not universal provider endpoints. The adapter translates them to the selected provider's real contract.
