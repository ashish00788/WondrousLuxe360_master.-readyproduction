# One-Time White-Label Validation Lab

The isolated simulator is deliberately removable and does not replace production transaction logic.

## What it validates
- ₹100/₹300/₹500 badge examples with 18% GST included
- 35% non-working pool split equally across 20 levels
- 1 BV = ₹1; 50% business-volume share
- 1:1 matching; 10% matching commission
- 10% achievers pool; other pools configurable
- 80/20 wallet split and ₹500 minimum payout
- 3-month paid duration with multiple active badges
- Free binary and paid-binary state
- 3 company reserve IDs and dummy sponsor tree
- Tree completion/migration demonstration
- Ecommerce profit/loss consolidation
- Franchise/dark-store/10–30 minute delivery configuration remains in the production API layer

## Endpoints
- POST `/api/v1/simulator/full`
- POST `/api/v1/simulator/badge`
- POST `/api/v1/simulator/matching`
- POST `/api/v1/simulator/tree`
- POST `/api/v1/simulator/duration`
- POST `/api/v1/simulator/economics`
- GET `/api/v1/simulator/rules`

The simulator is test data only. Real money, payout, tax and provider settlement must use the authoritative production ledger and real provider sandbox/production credentials.
