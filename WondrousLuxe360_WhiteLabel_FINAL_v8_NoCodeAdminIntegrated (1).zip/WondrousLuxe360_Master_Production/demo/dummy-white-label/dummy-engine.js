const fs = require('fs');
const path = require('path');
const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));

const money = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
const pct = (n, p) => money(Number(n) * Number(p) / 100);
const assert = (ok, msg) => { if (!ok) throw new Error(msg); };

function gstIncluded(amount, rate) {
  const gross = Number(amount);
  const base = gross / (1 + rate / 100);
  return { gross: money(gross), taxable: money(base), gst: money(gross - base) };
}

function badge(amount) {
  const tax = gstIncluded(amount, cfg.gstIncludedPct);
  const nonWorkingPool = pct(amount, cfg.nonWorkingPct);
  const perLevel = money(nonWorkingPool / cfg.nonWorkingLevels);
  return {
    amount: money(amount),
    taxableValue: tax.taxable,
    gstIncluded: tax.gst,
    nonWorkingPool,
    nonWorkingPerLevel: perLevel,
    durationMonths: cfg.paidDurationMonths
  };
}

function working({ leftBV, rightBV }) {
  const matchedBV = Math.min(leftBV, rightBV);
  const workingEligibleBV = pct(matchedBV, cfg.businessVolumeSharePct);
  const commission = pct(workingEligibleBV, cfg.matchingCommissionPct);
  const cash = pct(commission, cfg.cashWalletPct);
  const shopping = pct(commission, cfg.shoppingWalletPct);
  return { leftBV, rightBV, matchedBV, workingEligibleBV, commission, cashWallet: cash, shoppingWallet: shopping };
}

function buildTree() {
  const members = [
    { id: 'M001', name: 'Aarav Demo', sponsor: 'C001', badge: 500 },
    { id: 'M002', name: 'Bhavna Demo', sponsor: 'M001', badge: 300 },
    { id: 'M003', name: 'Chirag Demo', sponsor: 'M001', badge: 500 },
    { id: 'M004', name: 'Diya Demo', sponsor: 'M002', badge: 100 },
    { id: 'M005', name: 'Eshan Demo', sponsor: 'M002', badge: 300 },
    { id: 'M006', name: 'Faria Demo', sponsor: 'M003', badge: 500 },
    { id: 'M007', name: 'Gautam Demo', sponsor: 'M003', badge: 100 },
    { id: 'M008', name: 'Hina Demo', sponsor: 'M004', badge: 100 }
  ];
  return members.map((m, i) => ({ ...m, binaryPosition: i === 0 ? 'ROOT' : (i % 2 ? 'LEFT' : 'RIGHT'), treeId: 'T001', level: i === 0 ? 0 : Math.min(i, cfg.treeDepthBeforeNextTree) }));
}

function run() {
  assert(cfg.nonWorkingPct / cfg.nonWorkingLevels === 1.75, 'Expected 1.75% per non-working level');
  assert(cfg.cashWalletPct + cfg.shoppingWalletPct === 100, 'Wallet split must be 100%');

  const badges = cfg.badgeAmounts.map(badge);
  const tree = buildTree();
  const leftBV = 600;
  const rightBV = 500;
  const work = working({ leftBV, rightBV });

  const freeBinary = {
    enabled: cfg.freeBinary.enabled,
    unlimitedDepth: cfg.freeBinary.depth === 'UNLIMITED',
    ratio: cfg.freeBinary.ratio,
    shoppingOnly: cfg.freeBinary.bvShoppingPct === 100,
    paidBadgeDisables: cfg.freeBinary.paidBadgeDisables
  };

  const utility = [
    { service: 'mobile_recharge', gross: 500, commissionPct: 2, commission: pct(500, 2) },
    { service: 'electricity', gross: 1200, commissionPct: 1, commission: pct(1200, 1) },
    { service: 'gas', gross: 900, commissionPct: 1.5, commission: pct(900, 1.5) }
  ];
  const travel = [
    { service: 'hotel', gross: 5000, commissionPct: 8, commission: pct(5000, 8) },
    { service: 'flight', gross: 10000, commissionPct: 2, commission: pct(10000, 2) },
    { service: 'bus', gross: 1500, commissionPct: 3, commission: pct(1500, 3) },
    { service: 'car_rental', gross: 2500, commissionPct: 5, commission: pct(2500, 5) }
  ];
  const ecommerce = {
    orderGross: 3000,
    productCost: 2100,
    shipping: 100,
    paymentCost: 60,
    discount: 100,
    otherExpense: 50,
    profit: money(3000 - 2100 - 100 - 60 - 100 - 50)
  };
  const franchise = {
    applicationFee: 25000,
    securityDeposit: 10000,
    monthlyRevenueSharePct: 5,
    darkStore: true,
    deliveryTargetMinutes: '10-30'
  };

  const report = {
    demo: { ...cfg, generatedAt: new Date().toISOString() },
    badgeCalculations: badges,
    tree,
    freeBinary,
    workingBinary: work,
    nonWorkingExampleFor500Badge: badge(500),
    payoutRule: {
      minimumPayout: cfg.minimumPayout,
      cashWalletPct: cfg.cashWalletPct,
      shoppingWalletPct: cfg.shoppingWalletPct,
      dailyAutoPayoutCutoff: '00:00'
    },
    utilityServices: utility,
    travelServices: travel,
    ecommerce,
    franchiseAndDarkStore: franchise,
    achieversPoolExample: { sourceAmount: 1000, poolPct: cfg.achieversPoolPct, poolAmount: pct(1000, cfg.achieversPoolPct) },
    companyIds: cfg.companyIds,
    checks: {
      nonWorkingPerLevelPct: cfg.nonWorkingPct / cfg.nonWorkingLevels,
      walletRatio100: cfg.cashWalletPct + cfg.shoppingWalletPct === 100,
      oneBVEqualsOneRupee: cfg.bvPerRupee === 1,
      matchingIs1to1: true,
      demoOnly: true,
      removable: true
    }
  };
  return report;
}

module.exports = { run };
