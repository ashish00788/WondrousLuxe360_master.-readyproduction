# WondrousLuxe360 Dummy White-Label Calculation Lab

This folder is intentionally isolated and removable. It is a demonstration/simulation layer, not production member data.

## Baseline used
- ₹100 / ₹300 / ₹500 badges
- 18% GST included in badge price
- 1 BV = ₹1
- Business Volume share = 50%
- 1:1 matching
- Matching commission = 10%
- Non-working = 35% of each active badge amount
- 20 non-working levels => 1.75% of badge amount per level
- Free Binary = unlimited depth, 1:1, BV benefit shopping-only, disabled on paid badge activation
- Paid duration = 3 months
- Minimum payout = ₹500
- Cash/Shopping wallet = 80/20
- Achievers pool = 10%
- Company IDs = C001/C002/C003

## Run
`node demo/dummy-white-label/run-demo.js`

The script creates `DUMMY_CALCULATION_REPORT.json` with the complete dummy tree and sample calculations.

## Remove
Delete the entire `demo/dummy-white-label` directory. Production migrations and production services do not depend on this demo folder.

## Important
The commission figures for utility/travel providers are demonstration values only. Real provider commissions must come from the purchased provider contract/API configuration. Do not use the demo percentages for live settlement.
