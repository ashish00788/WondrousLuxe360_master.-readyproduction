#!/bin/bash
set -e
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  --set=runtime_password="$RUNTIME_PASSWORD" --set=migrator_password="$MIGRATOR_PASSWORD" <<'SQL'
DO $do$
BEGIN
 IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='app_runtime') THEN
   EXECUTE format('CREATE ROLE app_runtime LOGIN PASSWORD %L', :'runtime_password');
 END IF;
 IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='app_migrator') THEN
   EXECUTE format('CREATE ROLE app_migrator LOGIN PASSWORD %L', :'migrator_password');
 END IF;
END
$do$;
GRANT CONNECT ON DATABASE wondrousluxe360 TO app_runtime, app_migrator;
SQL
