# WondrousLuxe360 — Master Production Deployment Bundle

This bundle is a deployable production-oriented backend foundation with PostgreSQL migrations, transactional webhook processing, durable idempotency, immutable ledger controls, Razorpay order creation, health checks, Docker deployment, Nginx reverse proxy, and a Flutter mobile API client starter.

## Important boundary
The proprietary MLM/commission formulas were **not recreated or guessed**. The adapter at `backend/src/legacy/legacyCommissionLogic.js` must be replaced with the already-approved calculation implementation. This is the only intentional application-logic integration point.

## Quick deployment
1. Copy `infra/docker/.env.example` to `infra/docker/.env`.
2. Set strong random values for `POSTGRES_PASSWORD`, `RUNTIME_PASSWORD`, and `MIGRATOR_PASSWORD`.
3. Set real Razorpay production credentials and webhook secret.
4. Run `./scripts/deploy.sh`.
5. Verify `http://SERVER_IP:8080/health/ready`.
6. Put TLS in front of Nginx before exposing the API publicly.

## API
- `POST /api/v1/payments/orders` — requires `X-Idempotency-Key` and creates a Razorpay order server-side.
- `POST /api/v1/webhooks/razorpay` — raw-body HMAC verification before JSON parsing.
- `GET /health/live`
- `GET /health/ready`

## Security notes
- Never place Razorpay secret credentials in Android/iOS binaries.
- The runtime DB role cannot UPDATE/DELETE ledger lines.
- Ledger corrections use new reversal/adjustment journals rather than editing history.
- Redis is not required for financial correctness; PostgreSQL is the durable idempotency authority.
- Before production, add TLS, firewall rules, secret manager, database backups/PITR, monitoring, alerting, WAF/CDN and a tested disaster-recovery procedure.

## Dynamic Platform v3 additions

The production foundation has been extended with tenant-scoped dynamic rules, E-Commerce configuration, Free Binary configuration, dynamic levels/trees, badges, leadership ranks, pools, marketing templates, themes, inventory, orders, BV events, payout batches, and a separate Admin financial simulation endpoint.

### Run
1. Copy `backend/.env.example` to `backend/.env` and set a strong `DATABASE_URL` and `ADMIN_API_KEY`.
2. Start PostgreSQL using `infra/docker/docker-compose.yml`.
3. Run `cd backend && npm install`.
4. Run `npm run migrate`.
5. Run `npm run preflight`.
6. Start with `npm start`.

Admin APIs require `x-admin-key` and optionally `x-business-slug` (defaults to `wondrousluxe360`).

### Important production gate
This repository is a hardened implementation foundation plus the newly added dynamic business-data layer. Before processing real customer money, complete authentication/authorization integration, payment-provider production credentials, tax/legal configuration per jurisdiction, real payout adapters, queue workers, observability, backups/restore drills, penetration testing, and the approved proprietary commission matrix. Historical ledger records must remain immutable.


## White-label configuration
See `docs/WHITE_LABEL_CONFIGURATION.md` and `config/white-label-default.json`. Migration `007_white_label_core.sql` adds tenant-scoped configuration, cycles, sponsored genealogy, modules, calculation profiles, public metrics, geo and billing configuration.


## White-Label Final Configuration
- Legal name: Wondrous Indian Lifestyle PVT. LTD
- Domain: iwondrous.in
- Default theme: Black Gold
- Baseline calculation: ₹100
- Default business tree: 1 tree / 20 levels; Admin-expandable
- Service adapters: travel, utility/recharge, geo, notifications, tax/e-invoice, shipping, AI
- Provider credentials can be supplied through the secure No-Code Admin Integration Manager; server environment variables/secret manager remain supported for bootstrap and legacy integrations.
- This package does not claim that third-party provider accounts are purchased or activated.

## All-service adapter release
The platform now includes a dynamic service catalog and provider adapter covering utilities, travel, logistics, geo, communications, identity/KYC, commerce, AI, finance, marketplace and support categories. Provider credentials and exact API contracts remain environment/configuration concerns; no fabricated live credentials are included.


## Final consolidation
- Franchise application/approval/policy and contracts.
- Dark-store fulfillment nodes, inventory, delivery zones and delivery jobs.
- 10–30 minute delivery configuration and provider adapter hook.
- Franchise-to-dark-store linkage.


## No-Code Admin API Integration Manager
The release now includes `/api/v1/admin/integrations` and the admin UI at `/admin/integrations`. Authorized admins can store supported provider credentials encrypted at rest, test connections, and activate/deactivate providers without editing application code.

Set `INTEGRATION_ENCRYPTION_KEY` to 64 random hex characters (32 bytes). Example: `openssl rand -hex 32`. Provider-specific OAuth, signed-request, token-exchange or non-REST contracts may still require a one-time adapter; the no-code layer does not pretend that generic credentials automatically implement a provider's business API.


## No-Code Admin API Integration Manager
The release now includes `/api/v1/admin/integrations` and the admin UI at `/admin/integrations`. Authorized admins can store supported provider credentials encrypted at rest, test connections, and activate/deactivate providers without editing application code.

Set `INTEGRATION_ENCRYPTION_KEY` to 64 random hex characters (32 bytes). Example: `openssl rand -hex 32`. Provider-specific OAuth, signed-request, token-exchange or non-REST contracts may still require a one-time adapter; the no-code layer does not pretend that generic credentials automatically implement a provider's business API.
