# Mobile clients

The API is platform-neutral and supports Android and iOS. `flutter/` contains a starter client with the production API contract. For native builds, install Flutter 3.x and run `flutter create --platforms=android,ios mobile/flutter` once; the generated `android/` and `ios/` folders are intentionally reproducible build artifacts.

Configure `API_BASE_URL` in the app before release. Never ship Razorpay secret keys in the mobile app; only the public key ID may be exposed to the client.
