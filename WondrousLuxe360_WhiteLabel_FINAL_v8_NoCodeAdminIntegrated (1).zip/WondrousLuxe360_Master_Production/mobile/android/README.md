# Android release
Generate native project: `flutter create --platforms=android mobile/flutter`
Never embed gateway secret credentials.
