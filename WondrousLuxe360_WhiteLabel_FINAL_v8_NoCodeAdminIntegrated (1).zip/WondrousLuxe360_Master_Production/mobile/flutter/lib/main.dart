import 'package:flutter/material.dart';
import 'api_client.dart';
void main()=>runApp(const WondrousApp());
class WondrousApp extends StatelessWidget{const WondrousApp({super.key});@override Widget build(BuildContext c)=>MaterialApp(title:'WondrousLuxe360',home:Scaffold(appBar:AppBar(title:const Text('WondrousLuxe360')),body:const Center(child:Text('Production API client ready'))));}
