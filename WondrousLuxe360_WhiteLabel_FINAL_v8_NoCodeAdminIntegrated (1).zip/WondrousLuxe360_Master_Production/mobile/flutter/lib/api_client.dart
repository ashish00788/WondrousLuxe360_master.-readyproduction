import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:http/http.dart' as http;
class ApiClient{
 final String baseUrl; ApiClient(this.baseUrl);
 Future<Map<String,dynamic>> createOrder({required int amountPaise,required String userId,required String idempotencyKey,String? packageId}) async{
  final r=await http.post(Uri.parse('$baseUrl/api/v1/payments/orders'),headers:{'Content-Type':'application/json','X-Idempotency-Key':idempotencyKey},body:jsonEncode({'amountPaise':amountPaise,'userId':userId,'packageId':packageId}));
  final body=jsonDecode(r.body); if(r.statusCode>=400) throw Exception(body['error']??'Request failed'); return Map<String,dynamic>.from(body);
 }
 String fingerprint(Map<String,dynamic> body)=>sha256.convert(utf8.encode(jsonEncode(body))).toString();
}
