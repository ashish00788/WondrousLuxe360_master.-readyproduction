# iOS release
Generate native project: `flutter create --platforms=ios mobile/flutter`
Never embed gateway secret credentials.
